CodiceFiscale 4.0
=========

Calcolo del codice fiscale
Author 2011-2024 Codelinsoft <info@codelinsoft.it>

Per poter installare CodiceFiscale da sorgente bisogna 
scaricare il programma all'indirizzo:

http://www.codelinsoft.it/sito/2013-11-17-17-56-34/codice-fiscale.html

Una volta scaricato aprire il terminale e dicitare i seguenti comandi

tar -xvzf codicefiscale-4.0.tar.gz

cd codicefiscale-4.0

cmake -DCMAKE_INSTALL_PREFIX=directory

make-j5
sudo make install

------------------------------------------------------------------------
![ScreenShot](https://github.com/kratos83/CodiceFiscale/blob/master/codicefiscale.png)

------------------------------------------------------------------------
CodiceFiscale calcola anche quello estero.
# CodiceFiscale
