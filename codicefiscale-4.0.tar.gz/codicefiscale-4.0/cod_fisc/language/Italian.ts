<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>About</name>
    <message>
        <location filename="../ui/About.qml" line="81"/>
        <source>Copyright (C) 2014 Codelinsoft. All rights reserved.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/About.qml" line="99"/>
        <source>Compilato con le Qt: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/About.qml" line="117"/>
        <source>Versione del software: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/About.qml" line="133"/>
        <source>Torna indietro</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FindCapItalian</name>
    <message>
        <location filename="../ui/FindCapItalian.qml" line="60"/>
        <source>Cerca CAP( Codici avviamento postali )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/FindCapItalian.qml" line="79"/>
        <source>Seleziona comune</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/FindCapItalian.qml" line="124"/>
        <source>Cerca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/FindCapItalian.qml" line="133"/>
        <source>Torna indietro</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="../ui/Main.qml" line="61"/>
        <location filename="../ui/Main.qml" line="328"/>
        <source>CodiceFiscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Main.qml" line="124"/>
        <source>Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Main.qml" line="170"/>
        <location filename="../ui/Main.qml" line="304"/>
        <location filename="../ui/Main.qml" line="305"/>
        <source>Esci</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Main.qml" line="175"/>
        <source>Stampa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Main.qml" line="181"/>
        <source>Visualizza anteprima</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Main.qml" line="196"/>
        <source>Esporta in pdf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Main.qml" line="201"/>
        <source>Esporta in immagine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Main.qml" line="205"/>
        <source>Verifica codice fiscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Main.qml" line="210"/>
        <source>Verifica partita iva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Main.qml" line="215"/>
        <source>Cerca CAP(Codici avviamenti postali)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Main.qml" line="220"/>
        <source>Impostazioni</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Main.qml" line="225"/>
        <source>Aggiornamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Main.qml" line="230"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Main.qml" line="255"/>
        <source>Impostare il carattere per
una corretta visualizzazione
Se usi Linux imposta il carattere Noto Sans,
se usi windows imposta il carattere Tahoma,
se usi MacOsX imposta il carattere Fira Sans.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Main.qml" line="283"/>
        <location filename="../ui/Main.qml" line="284"/>
        <source>Calcola</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Main.qml" line="297"/>
        <location filename="../ui/Main.qml" line="298"/>
        <source>Cancella</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Main.qml" line="329"/>
        <source>Inserisci i dati correttamente.

Controlla il cognome
Controlla il nome
Controlla il sesso</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Message</name>
    <message>
        <location filename="../ui/Message.qml" line="89"/>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Page1</name>
    <message>
        <location filename="../ui/Page1.qml" line="62"/>
        <source>Impostazioni generali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Page1.qml" line="71"/>
        <source>Font editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Page1.qml" line="82"/>
        <location filename="../ui/Page1.qml" line="133"/>
        <source>Font Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Page1.qml" line="92"/>
        <location filename="../ui/Page1.qml" line="143"/>
        <source>Font size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Page1.qml" line="122"/>
        <source>Font application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Page1.qml" line="168"/>
        <source>Selezione della lingua</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Page1.qml" line="179"/>
        <source>Seleziona la lingua</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Page1.qml" line="199"/>
        <source>La selezione della lingua richiede il riavvio...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Page1.qml" line="219"/>
        <source>Torna indietro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Page1.qml" line="225"/>
        <source>Applica</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Page2</name>
    <message>
        <location filename="../ui/Page2.qml" line="59"/>
        <source>Aggiornamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Page2.qml" line="71"/>
        <source>Abilita aggiornamenti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Page2.qml" line="86"/>
        <source>Disabilita aggiornamenti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Page2.qml" line="105"/>
        <source>Aggiorna</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Page2.qml" line="130"/>
        <source>Torna indietro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/Page2.qml" line="136"/>
        <source>Applica</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageMain1</name>
    <message>
        <location filename="../ui/PageMain1.qml" line="78"/>
        <location filename="../ui/PageMain1.qml" line="84"/>
        <source>Cognome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/PageMain1.qml" line="91"/>
        <location filename="../ui/PageMain1.qml" line="97"/>
        <source>Nome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/PageMain1.qml" line="104"/>
        <source>Sesso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/PageMain1.qml" line="108"/>
        <source>M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/PageMain1.qml" line="113"/>
        <source>F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/PageMain1.qml" line="125"/>
        <source>Seleziona</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/PageMain1.qml" line="130"/>
        <source>Comuni</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/PageMain1.qml" line="130"/>
        <source>Stati</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/PageMain1.qml" line="144"/>
        <source>Comuni o Stato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/PageMain1.qml" line="157"/>
        <source>Data di nascita</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/PageMain1.qml" line="172"/>
        <source>Codice Fiscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/PageMain1.qml" line="181"/>
        <source>Calcolo codice fiscale</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageMain2</name>
    <message>
        <location filename="../ui/PageMain2.qml" line="92"/>
        <source>FACSIMILE</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VerifyCodicefiscale</name>
    <message>
        <location filename="../ui/VerifyCodicefiscale.qml" line="77"/>
        <location filename="../ui/VerifyCodicefiscale.qml" line="85"/>
        <source>Inserisci il codice fiscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/VerifyCodicefiscale.qml" line="107"/>
        <source>Verifica</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/VerifyCodicefiscale.qml" line="114"/>
        <source>Torna indietro</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VerifyPiva</name>
    <message>
        <location filename="../ui/VerifyPiva.qml" line="78"/>
        <location filename="../ui/VerifyPiva.qml" line="86"/>
        <source>Inserisci la partita iva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/VerifyPiva.qml" line="107"/>
        <source>Verifica</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/VerifyPiva.qml" line="114"/>
        <source>Torna indietro</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
