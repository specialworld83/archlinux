<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en" sourcelanguage="it_IT">
<context>
    <name>QObject</name>
    <message>
        <source>La versione del software installato Ã¨: </source>
        <translation type="vanished">This version installed is: </translation>
    </message>
    <message>
        <source>USA LA LINEA DI COMANDO:	 </source>
        <translation type="vanished">USAGE COMMAND LINE :	 </translation>
    </message>
    <message>
        <source>VISUALIZZA
</source>
        <translation type="vanished">DISPLAYS
</translation>
    </message>
    <message>
        <source>-p or --package 	</source>
        <translation type="vanished">-p or --package 	</translation>
    </message>
    <message>
        <source>Selezione del pacchetto da scaricare
</source>
        <translation type="vanished">Download package to select

</translation>
    </message>
    <message>
        <source>-u or --url 		</source>
        <translation type="vanished">-u or --url 		</translation>
    </message>
    <message>
        <source>Selezione dell&apos;indirizzo internet:
			 ESEMPIO: http://


</source>
        <translation type="vanished">Selectiing to url:
			 EXAMPLE: http://


</translation>
    </message>
    <message>
        <source>VISUALIZZA LA VERSIONE INSTALLATA DEL SOFTWARE:

</source>
        <translation type="vanished">DISPLAYS THE SOFTWARE VERSION:

</translation>
    </message>
    <message>
        <source>-v or --version 	</source>
        <translation type="vanished">-v or --version 	</translation>
    </message>
    <message>
        <source>Versione del software


</source>
        <translation type="vanished">Software version


</translation>
    </message>
    <message>
        <source>VISUALIZZA LE INFORMAZIONI DEL PROGRAMMA:

</source>
        <translation type="vanished">DISPLAYS THE SOFTWARE INFORMATION :

</translation>
    </message>
    <message>
        <source>-h or --help 		</source>
        <translation type="vanished">-h or --help 		</translation>
    </message>
    <message>
        <source>Informazioni del software.</source>
        <translation type="vanished">software information.</translation>
    </message>
    <message>
        <source>Comando non trovato: </source>
        <translation type="vanished">Command not found: </translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <source>Gestore aggiornamento</source>
        <translation>Update management</translation>
    </message>
    <message>
        <source>Download aggiornamento</source>
        <translation>Download update</translation>
    </message>
    <message>
        <source>Installazione</source>
        <translation>Installation</translation>
    </message>
    <message>
        <source>Installa aggiornamento</source>
        <translation>Install update</translation>
    </message>
</context>
<context>
    <name>update</name>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Annulla download&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Clear download&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Installazione</source>
        <translation type="vanished">Installation</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Download aggiornamento&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Download update&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Installa aggiornamento&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Install update&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Installa aggiornamento</source>
        <translation type="vanished">Install update</translation>
    </message>
    <message>
        <source>Downaload aggiornamento</source>
        <translation type="vanished">Download update</translation>
    </message>
    <message>
        <source>Gestore aggiornamento</source>
        <translation type="vanished">Update management</translation>
    </message>
    <message>
        <source>Scaricamento in corso di:  </source>
        <translation>Download in progress: </translation>
    </message>
    <message>
        <source>VelocitÃ  di scaricamento: </source>
        <translation type="vanished">Fast download: </translation>
    </message>
    <message>
        <source>  Dimensione: </source>
        <translation>  Size: </translation>
    </message>
    <message>
        <source> Tempo stimato: </source>
        <translation> Elapsed time: </translation>
    </message>
    <message>
        <source>Download fallito: </source>
        <translation>Download failed: </translation>
    </message>
    <message>
        <source>Scaricamento completato</source>
        <translation>Download completed</translation>
    </message>
    <message>
        <source>Scaricamento annullato</source>
        <translation>Clear download</translation>
    </message>
    <message>
        <source>Errore scaricamento</source>
        <translation>Download error</translation>
    </message>
    <message>
        <source>Download fallito </source>
        <translation>Download failed</translation>
    </message>
    <message>
        <source>Velocità di scaricamento: </source>
        <translation>Fast download: </translation>
    </message>
</context>
</TS>
