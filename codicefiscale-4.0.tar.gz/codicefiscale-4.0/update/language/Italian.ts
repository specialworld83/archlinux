<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it_IT">
<context>
    <name>main</name>
    <message>
        <source>Gestore aggiornamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Download aggiornamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Installazione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Installa aggiornamento</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>update</name>
    <message>
        <source>Scaricamento in corso di:  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Velocità di scaricamento: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>  Dimensione: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Tempo stimato: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Download fallito: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scaricamento completato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scaricamento annullato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Errore scaricamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Download fallito </source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
