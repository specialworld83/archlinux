#!/usr/bin/env bash

../build_mingw32
