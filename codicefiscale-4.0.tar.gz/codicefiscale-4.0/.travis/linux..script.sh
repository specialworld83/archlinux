#!/usr/bin/env bash

cmake ..
