#!/usr/bin/env bash

../build_mingw64
