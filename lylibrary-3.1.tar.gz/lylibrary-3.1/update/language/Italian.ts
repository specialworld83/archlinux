<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="it_IT">
<context>
    <name>QObject</name>
    <message>
        <source>La versione del software installato Ã¨: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>USA LA LINEA DI COMANDO:	 </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VISUALIZZA
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>-p or --package 	</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selezione del pacchetto da scaricare
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>-u or --url 		</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selezione dell&apos;indirizzo internet:
			 ESEMPIO: http://


</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VISUALIZZA LA VERSIONE INSTALLATA DEL SOFTWARE:

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>-v or --version 	</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Versione del software


</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VISUALIZZA LE INFORMAZIONI DEL PROGRAMMA:

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>-h or --help 		</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Informazioni del software.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comando non trovato: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>update</name>
    <message>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Annulla download&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Installazione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Download aggiornamento&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Installa aggiornamento&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Installa aggiornamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Downaload aggiornamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gestore aggiornamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scaricamento in corso di:  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VelocitÃ  di scaricamento: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>  Dimensione: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Tempo stimato: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Download fallito: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scaricamento completato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scaricamento annullato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Errore scaricamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Download fallito </source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
