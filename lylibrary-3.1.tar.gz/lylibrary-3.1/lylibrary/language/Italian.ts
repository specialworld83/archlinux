<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../ui/mainwindow.ui" line="224"/>
        <location filename="../mainwindow.cpp" line="322"/>
        <location filename="../mainwindow.cpp" line="345"/>
        <location filename="../ui_mainwindow.h" line="775"/>
        <source>Strumenti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="254"/>
        <location filename="../ui/mainwindow.ui" line="937"/>
        <location filename="../ui_mainwindow.h" line="717"/>
        <location filename="../ui_mainwindow.h" line="776"/>
        <source>Codice fiscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="321"/>
        <location filename="../ui_mainwindow.h" line="777"/>
        <source>Preferenze</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="368"/>
        <location filename="../ui_mainwindow.h" line="778"/>
        <source>Gestione plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="70"/>
        <location filename="../ui_mainwindow.h" line="772"/>
        <source>Prestiti e Scadenze</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="100"/>
        <location filename="../mainwindow.cpp" line="334"/>
        <location filename="../mainwindow.cpp" line="357"/>
        <location filename="../ui_mainwindow.h" line="773"/>
        <source>Scadenze</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="154"/>
        <location filename="../ui_mainwindow.h" line="774"/>
        <source>Prestito libri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="680"/>
        <location filename="../ui_mainwindow.h" line="786"/>
        <source>Visualizza scadenza Libri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="388"/>
        <location filename="../ui_mainwindow.h" line="779"/>
        <source>Informazioni</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="418"/>
        <location filename="../ui_mainwindow.h" line="780"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="459"/>
        <location filename="../ui_mainwindow.h" line="781"/>
        <source>Documentazione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="516"/>
        <location filename="../mainwindow.cpp" line="325"/>
        <location filename="../mainwindow.cpp" line="348"/>
        <location filename="../ui_mainwindow.h" line="782"/>
        <source>Anagrafica</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="552"/>
        <location filename="../ui_mainwindow.h" line="783"/>
        <source>Anagrafica libri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="606"/>
        <location filename="../ui/mainwindow.ui" line="1059"/>
        <location filename="../ui_mainwindow.h" line="740"/>
        <location filename="../ui_mainwindow.h" line="784"/>
        <source>Categorie libri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="647"/>
        <location filename="../ui_mainwindow.h" line="785"/>
        <source>Anagrafica clienti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="331"/>
        <location filename="../mainwindow.cpp" line="354"/>
        <source>Prestiti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="337"/>
        <location filename="../mainwindow.cpp" line="360"/>
        <source>Documenti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="789"/>
        <location filename="../ui_mainwindow.h" line="789"/>
        <source>Fi&amp;le</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="795"/>
        <location filename="../ui_mainwindow.h" line="790"/>
        <source>&amp;Anagrafica </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="799"/>
        <location filename="../ui/mainwindow.ui" line="877"/>
        <location filename="../ui_mainwindow.h" line="791"/>
        <location filename="../ui_mainwindow.h" line="798"/>
        <source>&amp;Gestione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="821"/>
        <location filename="../ui_mainwindow.h" line="792"/>
        <source>&amp;Prestiti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="828"/>
        <location filename="../ui_mainwindow.h" line="793"/>
        <source>&amp;Scadenze</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="841"/>
        <location filename="../ui_mainwindow.h" line="794"/>
        <source>St&amp;rumenti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="845"/>
        <location filename="../ui_mainwindow.h" line="795"/>
        <source>&amp;Plugins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="859"/>
        <location filename="../ui_mainwindow.h" line="796"/>
        <source>&amp;Informazioni</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="868"/>
        <location filename="../ui_mainwindow.h" line="797"/>
        <source>&amp;Documenti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="910"/>
        <location filename="../ui_mainwindow.h" line="714"/>
        <source>&amp;Anagrafica clienti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="919"/>
        <location filename="../ui_mainwindow.h" line="715"/>
        <source>Anagrafica &amp;libri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="928"/>
        <location filename="../ui_mainwindow.h" line="716"/>
        <source>Nuova assistenza</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="946"/>
        <location filename="../ui_mainwindow.h" line="718"/>
        <source>&amp;About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="955"/>
        <location filename="../ui_mainwindow.h" line="719"/>
        <source>Crea database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="964"/>
        <location filename="../ui_mainwindow.h" line="720"/>
        <source>Elimina database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="973"/>
        <location filename="../ui_mainwindow.h" line="721"/>
        <source>Backup e restore database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="982"/>
        <location filename="../ui/mainwindow.ui" line="985"/>
        <location filename="../ui/mainwindow.ui" line="988"/>
        <location filename="../ui_mainwindow.h" line="722"/>
        <location filename="../ui_mainwindow.h" line="723"/>
        <location filename="../ui_mainwindow.h" line="725"/>
        <source>Anagrafica azienda</source>
        <extracomment>Anagrafica zzienda
----------
Anagrafica azienda</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1000"/>
        <location filename="../ui_mainwindow.h" line="730"/>
        <source>Chiudi assistenza</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1009"/>
        <location filename="../ui_mainwindow.h" line="731"/>
        <source>Fatture acquisto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1018"/>
        <location filename="../ui_mainwindow.h" line="732"/>
        <source>Anagrafica fornitori</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1023"/>
        <location filename="../ui_mainwindow.h" line="733"/>
        <source>Anagrafica tipo porto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1028"/>
        <location filename="../ui_mainwindow.h" line="734"/>
        <source>Anagrafica banche</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1033"/>
        <location filename="../ui_mainwindow.h" line="735"/>
        <source>Anagrafica causali di trasporo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1042"/>
        <location filename="../ui_mainwindow.h" line="736"/>
        <source>Anagrafica Iva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1047"/>
        <location filename="../ui_mainwindow.h" line="737"/>
        <source>Anagrafica categorie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1056"/>
        <location filename="../ui_mainwindow.h" line="738"/>
        <source>&amp;Categorie libri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1068"/>
        <location filename="../ui_mainwindow.h" line="742"/>
        <source>&amp;Prestito libri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1077"/>
        <location filename="../ui_mainwindow.h" line="743"/>
        <source>&amp;Documentazione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1086"/>
        <location filename="../ui_mainwindow.h" line="744"/>
        <source>P&amp;referenze</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1095"/>
        <location filename="../ui_mainwindow.h" line="745"/>
        <source>Lancia wizard di configurazione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1104"/>
        <location filename="../ui_mainwindow.h" line="746"/>
        <source>&amp;Scadenze Libri </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1113"/>
        <location filename="../ui_mainwindow.h" line="747"/>
        <source>&amp;Gestione plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1122"/>
        <location filename="../ui_mainwindow.h" line="748"/>
        <source>Anagrafica &amp;prodotti digitali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1134"/>
        <location filename="../ui_mainwindow.h" line="749"/>
        <source>Scadenze &amp;prodotti digitali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1143"/>
        <location filename="../ui_mainwindow.h" line="750"/>
        <source>Prestito prodotti &amp;digitali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1152"/>
        <location filename="../ui_mainwindow.h" line="751"/>
        <source>A&amp;nagrafica pagamenti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1161"/>
        <location filename="../ui_mainwindow.h" line="752"/>
        <source>Ca&amp;lcola codicefiscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1166"/>
        <location filename="../ui_mainwindow.h" line="753"/>
        <source>Causali &amp;di trasporto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1175"/>
        <location filename="../ui_mainwindow.h" line="754"/>
        <source>Anagrafica &amp;iva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1180"/>
        <location filename="../ui_mainwindow.h" line="755"/>
        <source>Anagrafica &amp;banche</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1185"/>
        <location filename="../ui_mainwindow.h" line="756"/>
        <source>Ana&amp;grafica azienda</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1194"/>
        <location filename="../ui_mainwindow.h" line="757"/>
        <source>&amp;Fattura d&apos;aquisto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1203"/>
        <location filename="../ui_mainwindow.h" line="758"/>
        <source>Anagrafica &amp;fornitori</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1217"/>
        <location filename="../ui_mainwindow.h" line="760"/>
        <source>Fattura &amp;di vendita</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1222"/>
        <location filename="../ui_mainwindow.h" line="761"/>
        <source>&amp;Carico magazzino</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1227"/>
        <location filename="../ui_mainwindow.h" line="762"/>
        <source>&amp;Scarico magazzino</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1242"/>
        <location filename="../ui_mainwindow.h" line="765"/>
        <source>&amp;Installa plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1260"/>
        <location filename="../ui_mainwindow.h" line="767"/>
        <source>&amp;Cerca CAP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1269"/>
        <location filename="../ui_mainwindow.h" line="768"/>
        <source>&amp;Verifica partita iva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1278"/>
        <location filename="../ui_mainwindow.h" line="769"/>
        <source>&amp;Ricerca aggiornamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1292"/>
        <location filename="../ui_mainwindow.h" line="771"/>
        <source>Verifica codice &amp;fiscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1208"/>
        <location filename="../ui_mainwindow.h" line="759"/>
        <source>Fattura di vendita</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1232"/>
        <location filename="../ui_mainwindow.h" line="763"/>
        <source>Acquista nuova licenza</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1237"/>
        <location filename="../ui_mainwindow.h" line="764"/>
        <source>Inserisci nuovo numero di serie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1251"/>
        <location filename="../ui_mainwindow.h" line="766"/>
        <source>Calcola codice fiscale estero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="1283"/>
        <location filename="../ui_mainwindow.h" line="770"/>
        <source>Verifica codice fiscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="66"/>
        <source>Mi&amp;nimiza</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="69"/>
        <source>Ma&amp;ssimiza</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="72"/>
        <source>&amp;Ripristina</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="901"/>
        <location filename="../mainwindow.cpp" line="75"/>
        <location filename="../ui_mainwindow.h" line="713"/>
        <source>&amp;Esci</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="78"/>
        <source>Aggiorna</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="80"/>
        <source>Impostazioni</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="135"/>
        <source>Ctrl+H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="138"/>
        <source>Ctrl+ESC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="141"/>
        <source>Ctrl+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="144"/>
        <source>Ctrl+G</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="226"/>
        <source>Vi sono </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="226"/>
        <source> scadenze</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="233"/>
        <source>Mancano </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="233"/>
        <source> giorni alla scadenza del prestito</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="276"/>
        <source>Avviato...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="292"/>
        <source>Disattivato...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="328"/>
        <location filename="../mainwindow.cpp" line="351"/>
        <source>Plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="420"/>
        <source>Backup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="421"/>
        <source>Sono passati 15 giorni senza eseguire un backup.
Vuoi eseguirlo adesso?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="459"/>
        <source>LyLibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="460"/>
        <source>Errore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="461"/>
        <source>Inserire i campi dell&apos;azienda</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="478"/>
        <source>Apertura anagrafica azienda....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="492"/>
        <source>Apertura carico magazzino....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="506"/>
        <source>Apertura scarico magazzino....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="518"/>
        <source>Apertura fattura di vendita....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="533"/>
        <source>Apertura anagrafica banca....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="550"/>
        <source>open source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="580"/>
        <source>Apertura preferenze....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="615"/>
        <source>Lylibrary </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="616"/>
        <source>rilasciato in licenza a </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="634"/>
        <source>Apertura Prestito libri....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="650"/>
        <source>Apertura categorie....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="658"/>
        <source>Chiudi Lylibrary....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="672"/>
        <source>Apertura about....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="685"/>
        <source>Apertura causali di trasporto....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="694"/>
        <source>Apertura calcolo codice fiscale italiano....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="709"/>
        <source>Apertura anagrafica pagamento....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="723"/>
        <source>Apertura anagrafica iva...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="737"/>
        <source>Apertura fattura d&apos;acquisto....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="875"/>
        <location filename="../mainwindow.cpp" line="895"/>
        <location filename="../mainwindow.cpp" line="912"/>
        <source>Il plugin è stato installato correttamente...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="881"/>
        <location filename="../mainwindow.cpp" line="901"/>
        <location filename="../mainwindow.cpp" line="918"/>
        <source>Il plugin non è stato installato correttamente... </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="970"/>
        <source>Apertura finestra per verificare il codice fiscale...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="784"/>
        <source>Apertura anagrafica libri....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="419"/>
        <location filename="../mainwindow.cpp" line="585"/>
        <location filename="../mainwindow.cpp" line="593"/>
        <location filename="../mainwindow.cpp" line="799"/>
        <location filename="../mainwindow.cpp" line="875"/>
        <location filename="../mainwindow.cpp" line="881"/>
        <location filename="../mainwindow.cpp" line="895"/>
        <location filename="../mainwindow.cpp" line="901"/>
        <location filename="../mainwindow.cpp" line="912"/>
        <location filename="../mainwindow.cpp" line="918"/>
        <source>Lylibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="585"/>
        <source>Aggiornamento automatico attivato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="593"/>
        <source>Aggiornamento automatico disattivato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="751"/>
        <source>Apertura anagrafica fornitori...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="767"/>
        <source>Apertura anagrafica utenti....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="800"/>
        <source>Il programma continuerE0  a funzionare nella barra delle applicazioni. Per terminare il programma scegliere &lt;b&gt; Esci &lt;/b&gt; nel menu contestuale del vassoio di sistema... </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="819"/>
        <source>Database inizializzato correttamente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="836"/>
        <source>Apertura anagrafica prestiti libri....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="868"/>
        <location filename="../mainwindow.cpp" line="887"/>
        <location filename="../mainwindow.cpp" line="905"/>
        <source>Open file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="868"/>
        <location filename="../mainwindow.cpp" line="887"/>
        <location filename="../mainwindow.cpp" line="905"/>
        <source>Plugin lylibrary(*.zip);;Tutti i file(*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="954"/>
        <source>Apertura finestra per cercare il cap...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="962"/>
        <source>Apertura finestra per verificare la partita iva...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../main.cpp" line="33"/>
        <source>Aggiornamento database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.cpp" line="34"/>
        <source>Prima di effettuare l&apos;aggiornamento al
database accertati di averne salvato
una copia...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.cpp" line="147"/>
        <source>Avvio applicazione...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.cpp" line="150"/>
        <source>Avvio database...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.cpp" line="175"/>
        <source>Errore di connessione al DB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.cpp" line="176"/>
        <source>Controllare di aver installato MySql e di aver creato il DB lylibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="421"/>
        <source>Cod. Art.: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="422"/>
        <source>Codice a barre: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="423"/>
        <source>Titolo: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="424"/>
        <source>Descrizione: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="425"/>
        <source>Autore: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="426"/>
        <source>Lingua: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="427"/>
        <source>Categoria libro: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="428"/>
        <source>Info editore: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="429"/>
        <source>Collocazione: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="430"/>
        <source>Quantità: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="452"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="456"/>
        <source>Lylibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="456"/>
        <source>Impossibile aprire %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="469"/>
        <source>Anteprima di stampa.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="487"/>
        <source>Esporta PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="488"/>
        <source>Pdf Files(*.pdf);;Tutti i file(*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="506"/>
        <source>Esporta CSV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="507"/>
        <source>CSV(*.csv);;Tutti i file(*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="623"/>
        <location filename="../articoli.cpp" line="639"/>
        <location filename="../articoli.cpp" line="654"/>
        <source>LyLibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="623"/>
        <location filename="../articoli.cpp" line="639"/>
        <source>Impossibile ottenere il barcode....
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="654"/>
        <source>Seleziona una riga per stampare l&apos;etichetta....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="763"/>
        <source>Chiudi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="766"/>
        <source>Elimina</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="769"/>
        <source>Nuovo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="772"/>
        <source>Salva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="775"/>
        <source>Aggiorna</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="778"/>
        <source>Stampa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="44"/>
        <source>Modern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="44"/>
        <source>Elegant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="44"/>
        <source>Nero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../print.cpp" line="156"/>
        <source>Elenco Clienti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/main.cpp" line="24"/>
        <source>La versione del software installato è: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/main.cpp" line="29"/>
        <source>USA LA LINEA DI COMANDO:	 </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/main.cpp" line="29"/>
        <source>VISUALIZZA
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/main.cpp" line="30"/>
        <source>-p or --package 	</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/main.cpp" line="30"/>
        <source>Selezione del pacchetto da scaricare
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/main.cpp" line="31"/>
        <source>-u or --url 		</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/main.cpp" line="31"/>
        <source>Selezione dell&apos;indirizzo internet:
			 ESEMPIO: http://


</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/main.cpp" line="33"/>
        <source>VISUALIZZA LA VERSIONE INSTALLATA DEL SOFTWARE:

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/main.cpp" line="34"/>
        <source>-v or --version 	</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/main.cpp" line="34"/>
        <source>Versione del software


</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/main.cpp" line="35"/>
        <source>VISUALIZZA LE INFORMAZIONI DEL PROGRAMMA:

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/main.cpp" line="36"/>
        <source>-h or --help 		</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/main.cpp" line="36"/>
        <source>Informazioni del software.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/main.cpp" line="40"/>
        <source>Comando non trovato: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utility/main.cpp" line="10"/>
        <source>Database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utility/main.cpp" line="11"/>
        <source>Il database esiste già?Se esiste vai avanti.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ResizeDialog</name>
    <message>
        <location filename="../resizedialog.cpp" line="20"/>
        <source>Ridimensiona immagine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../resizedialog.cpp" line="26"/>
        <source>Larghezza</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../resizedialog.cpp" line="30"/>
        <source>Altezza</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../resizedialog.cpp" line="35"/>
        <source>Media</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../resizedialog.cpp" line="36"/>
        <source>Bilineare</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../resizedialog.cpp" line="38"/>
        <source>Mantieni proporzioni</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../resizedialog.cpp" line="41"/>
        <source>Re&amp;set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../resizedialog.cpp" line="42"/>
        <source>&amp;Cancella</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../resizedialog.cpp" line="43"/>
        <source>&amp;Ridimensiona</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../resizedialog.cpp" line="48"/>
        <location filename="../resizedialog.cpp" line="52"/>
        <source>pixels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../resizedialog.cpp" line="54"/>
        <source>Filtro</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <location filename="../ui/about.ui" line="26"/>
        <location filename="../ui/about.ui" line="109"/>
        <location filename="../ui_about.h" line="414"/>
        <location filename="../ui_about.h" line="433"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/about.ui" line="127"/>
        <location filename="../ui_about.h" line="415"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;A Cut Above The Rest&apos;; font-size:26pt; font-weight:400; font-style:italic;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/about.ui" line="167"/>
        <location filename="../ui/about.ui" line="170"/>
        <location filename="../ui_about.h" line="422"/>
        <location filename="../ui_about.h" line="424"/>
        <source>Chiudi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/about.ui" line="197"/>
        <location filename="../ui_about.h" line="425"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Noto Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;table border=&quot;0&quot; style=&quot;-qt-table-type: root; margin-top:4px; margin-bottom:4px; margin-left:4px; margin-right:4px;&quot;&gt;
&lt;tr&gt;
&lt;td style=&quot;border: none;&quot;&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://www.codelinsoft.it&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;© 2013 - 2016 Angelo e Calogero Scarnà. Tutti i diritti riservati&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/about.ui" line="233"/>
        <location filename="../ui_about.h" line="434"/>
        <source>Licenza</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/about.ui" line="461"/>
        <location filename="../ui_about.h" line="440"/>
        <source>Contatti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/about.ui" line="467"/>
        <location filename="../ui_about.h" line="435"/>
        <source>Per contattarci e richiedere info sul prodotto o informazioni tecniche vivitate il nostro sito web
oppure il nostro forum:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/about.ui" line="475"/>
        <location filename="../ui_about.h" line="437"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.codelinsoft.it&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.codelinsoft.it&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/about.ui" line="485"/>
        <location filename="../ui_about.h" line="438"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.codelinsoft.it/sito/index.php/community&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.codelinsoft.it/sito/index.php/community&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/about.ui" line="495"/>
        <location filename="../ui_about.h" line="439"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Per avere un maggior aiuto compilate il form che trovate alla pagina contatti del nostro sito.&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Software realizzato per l&apos; I.C. &amp;quot;Via Raiberi&amp;quot; di Monza e per l&apos; I.C.S. Paolo e Larissa Pini di Milano&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="17"/>
        <source>Lylibrary </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>articoli</name>
    <message>
        <location filename="../ui/articoli.ui" line="17"/>
        <location filename="../ui_articoli.h" line="602"/>
        <source>Lista libri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/articoli.ui" line="95"/>
        <location filename="../ui_articoli.h" line="603"/>
        <source>Informazioni dettagliate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/articoli.ui" line="175"/>
        <location filename="../ui_articoli.h" line="605"/>
        <source>Inserisci immagine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/articoli.ui" line="283"/>
        <location filename="../ui_articoli.h" line="606"/>
        <source>Titolo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/articoli.ui" line="305"/>
        <location filename="../ui_articoli.h" line="607"/>
        <source>Cod. Libro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/articoli.ui" line="342"/>
        <location filename="../ui_articoli.h" line="608"/>
        <source>Descizione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/articoli.ui" line="349"/>
        <location filename="../articoli.cpp" line="387"/>
        <location filename="../ui_articoli.h" line="609"/>
        <source>Info editore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/articoli.ui" line="356"/>
        <location filename="../articoli.cpp" line="385"/>
        <location filename="../ui_articoli.h" line="610"/>
        <source>Collocazione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/articoli.ui" line="363"/>
        <location filename="../ui_articoli.h" line="611"/>
        <source>Tipo di libro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/articoli.ui" line="370"/>
        <location filename="../articoli.cpp" line="382"/>
        <location filename="../ui_articoli.h" line="612"/>
        <source>Autore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/articoli.ui" line="410"/>
        <location filename="../ui_articoli.h" line="613"/>
        <source>Image dir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/articoli.ui" line="430"/>
        <location filename="../ui_articoli.h" line="615"/>
        <source>Cod. a barre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/articoli.ui" line="440"/>
        <location filename="../articoli.cpp" line="383"/>
        <location filename="../ui_articoli.h" line="616"/>
        <source>Lingua</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/articoli.ui" line="447"/>
        <location filename="../articoli.cpp" line="386"/>
        <location filename="../ui_articoli.h" line="617"/>
        <source>Quantità</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/articoli.ui" line="496"/>
        <location filename="../ui_articoli.h" line="618"/>
        <source>Cerca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/articoli.ui" line="523"/>
        <location filename="../ui_articoli.h" line="620"/>
        <source>ISBN Barcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/articoli.ui" line="550"/>
        <location filename="../ui_articoli.h" line="622"/>
        <source>Esporta in pdf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/articoli.ui" line="564"/>
        <location filename="../ui_articoli.h" line="626"/>
        <source>Nuovo libro.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/articoli.ui" line="578"/>
        <location filename="../ui_articoli.h" line="630"/>
        <source>Salva libri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/articoli.ui" line="592"/>
        <location filename="../ui_articoli.h" line="634"/>
        <source>Modifica libro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/articoli.ui" line="606"/>
        <location filename="../ui_articoli.h" line="638"/>
        <source>Elimina un libro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/articoli.ui" line="620"/>
        <location filename="../ui_articoli.h" line="642"/>
        <source>Stampa lista libri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/articoli.ui" line="634"/>
        <location filename="../ui_articoli.h" line="646"/>
        <source>Esci da anagrafica
libri.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/articoli.ui" line="662"/>
        <location filename="../ui_articoli.h" line="651"/>
        <source>Stampa lista
codice a barre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/articoli.ui" line="677"/>
        <location filename="../ui_articoli.h" line="656"/>
        <source>Esporta in excel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="27"/>
        <source>Ctrl+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="30"/>
        <source>Ctrl+D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="33"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="38"/>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="41"/>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="44"/>
        <source>Ctrl+M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="47"/>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="70"/>
        <source>Cerca per codice a barre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="70"/>
        <source>Cerca per libro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="70"/>
        <source>Cerca per autore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="141"/>
        <source>Lylibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="142"/>
        <source>Avviso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="143"/>
        <source>Inserisci il testo nella casella cerca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="222"/>
        <location filename="../articoli.cpp" line="289"/>
        <location filename="../articoli.cpp" line="336"/>
        <source>LyLibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="222"/>
        <source>Selezionare una riga da eliminare...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="239"/>
        <location filename="../articoli.cpp" line="255"/>
        <source>Voce non eliminabile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="240"/>
        <source>E&apos; una voce utilizzata in anagrafica clienti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="256"/>
        <source>Impossibile eliminare...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="289"/>
        <source>Selezionare una riga da modificare...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="320"/>
        <source>Voce non aggiornabile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="321"/>
        <source>Impossibile aggiornare</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="336"/>
        <source>Inserisci prima i dati correttamente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="364"/>
        <source>Non puoi inserire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="365"/>
        <source>Impossibile inserire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="378"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="379"/>
        <source>Codice a barre.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="380"/>
        <source>Titolo.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="381"/>
        <source>Descrizione.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="384"/>
        <source>Categoria</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../articoli.cpp" line="388"/>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>azienda</name>
    <message>
        <location filename="../ui/azienda.ui" line="23"/>
        <location filename="../ui_azienda.h" line="322"/>
        <source>Azienda</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/azienda.ui" line="45"/>
        <location filename="../ui_azienda.h" line="324"/>
        <source>Anagrafica azienda</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/azienda.ui" line="51"/>
        <location filename="../ui_azienda.h" line="326"/>
        <source>Codice fiscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/azienda.ui" line="58"/>
        <location filename="../ui_azienda.h" line="327"/>
        <source>Partita IVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/azienda.ui" line="68"/>
        <location filename="../ui_azienda.h" line="328"/>
        <source>Località</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/azienda.ui" line="78"/>
        <location filename="../ui_azienda.h" line="329"/>
        <source>CAP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/azienda.ui" line="85"/>
        <location filename="../ui_azienda.h" line="331"/>
        <source>Esci da anagrafica 
azienda</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/azienda.ui" line="122"/>
        <location filename="../ui_azienda.h" line="336"/>
        <source>Salva azienda</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/azienda.ui" line="149"/>
        <location filename="../ui_azienda.h" line="339"/>
        <source>Indirizzo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/azienda.ui" line="156"/>
        <location filename="../ui_azienda.h" line="340"/>
        <source>E-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/azienda.ui" line="179"/>
        <location filename="../ui_azienda.h" line="341"/>
        <source>Fax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/azienda.ui" line="196"/>
        <location filename="../ui_azienda.h" line="342"/>
        <source>Telefono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/azienda.ui" line="210"/>
        <location filename="../ui_azienda.h" line="343"/>
        <source>PROV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/azienda.ui" line="246"/>
        <location filename="../ui_azienda.h" line="344"/>
        <source>Ragione sociale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/azienda.ui" line="260"/>
        <location filename="../ui_azienda.h" line="345"/>
        <source>Sito web</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/azienda.ui" line="273"/>
        <location filename="../ui_azienda.h" line="347"/>
        <source>Elimina azienda</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../azienda.cpp" line="62"/>
        <location filename="../azienda.cpp" line="89"/>
        <source>Errore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../azienda.cpp" line="63"/>
        <source>Impossibile aggiornare</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../azienda.cpp" line="90"/>
        <source>Impossibile inserire
 </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../azienda.cpp" line="116"/>
        <location filename="../azienda.cpp" line="134"/>
        <source>Voce non eliminabile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../azienda.cpp" line="135"/>
        <source>Impossibile eliminare 
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>banche</name>
    <message>
        <location filename="../ui/banche.ui" line="14"/>
        <location filename="../ui_banche.h" line="245"/>
        <source>Anagrafica banca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/banche.ui" line="102"/>
        <location filename="../ui_banche.h" line="247"/>
        <source>Esci da anagrafica
banca.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/banche.ui" line="123"/>
        <location filename="../ui_banche.h" line="252"/>
        <source>Elimina banca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/banche.ui" line="143"/>
        <location filename="../ui_banche.h" line="256"/>
        <source>Nuova banca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/banche.ui" line="163"/>
        <location filename="../ui_banche.h" line="260"/>
        <source>Salva banca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/banche.ui" line="183"/>
        <location filename="../ui_banche.h" line="264"/>
        <source>Esporta in pdf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/banche.ui" line="202"/>
        <location filename="../banche.cpp" line="165"/>
        <location filename="../ui_banche.h" line="267"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/banche.ui" line="216"/>
        <location filename="../banche.cpp" line="166"/>
        <location filename="../ui_banche.h" line="268"/>
        <source>IBAN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/banche.ui" line="226"/>
        <location filename="../ui_banche.h" line="269"/>
        <source>Nome banca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/banche.ui" line="236"/>
        <location filename="../banche.cpp" line="168"/>
        <location filename="../ui_banche.h" line="270"/>
        <source>CAP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/banche.ui" line="259"/>
        <location filename="../banche.cpp" line="170"/>
        <location filename="../ui_banche.h" line="271"/>
        <source>Citta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/banche.ui" line="282"/>
        <location filename="../banche.cpp" line="169"/>
        <location filename="../ui_banche.h" line="272"/>
        <source>Indirizzo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../banche.cpp" line="47"/>
        <source>LyLibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../banche.cpp" line="47"/>
        <source>Inserisci correttamente i dati</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../banche.cpp" line="67"/>
        <location filename="../banche.cpp" line="96"/>
        <location filename="../banche.cpp" line="138"/>
        <source>Errore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../banche.cpp" line="68"/>
        <source>Impossibile aggiornare.Controlla correttamente i dati.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../banche.cpp" line="97"/>
        <source>Impossibile inserire.Controlla correttamente i dati.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../banche.cpp" line="139"/>
        <source>Impossibile eliminare</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../banche.cpp" line="167"/>
        <source>Banca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../banche.cpp" line="203"/>
        <source>Esporta PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../banche.cpp" line="204"/>
        <source>Pdf Files(*.pdf);;Tutti i file(*.*)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>barcode</name>
    <message>
        <location filename="../ui/barcode.ui" line="17"/>
        <location filename="../ui_barcode.h" line="43"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../barcode.cpp" line="66"/>
        <source>EAN13 Barcode test generator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../barcode.cpp" line="68"/>
        <source>Arbitrary size</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>carico_mag</name>
    <message>
        <location filename="../ui/carico_mag.ui" line="14"/>
        <location filename="../ui_carico_mag.h" line="186"/>
        <source>carico_mag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/carico_mag.ui" line="20"/>
        <location filename="../ui_carico_mag.h" line="187"/>
        <source>Carico magazzino</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/carico_mag.ui" line="26"/>
        <location filename="../ui_carico_mag.h" line="188"/>
        <source>Totale acquistato in magazzino</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/carico_mag.ui" line="80"/>
        <location filename="../ui_carico_mag.h" line="192"/>
        <source>Esci</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/carico_mag.ui" line="100"/>
        <location filename="../ui_carico_mag.h" line="196"/>
        <source>Esporta in excel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/carico_mag.ui" line="120"/>
        <location filename="../ui_carico_mag.h" line="200"/>
        <source>Esporta in pdf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/carico_mag.ui" line="134"/>
        <location filename="../ui_carico_mag.h" line="204"/>
        <source>Stampa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/carico_mag.ui" line="148"/>
        <location filename="../ui_carico_mag.h" line="208"/>
        <source>Elimina</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/carico_mag.ui" line="51"/>
        <location filename="../ui_carico_mag.h" line="189"/>
        <source>Quantità residua in magazzino</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/carico_mag.ui" line="60"/>
        <location filename="../ui_carico_mag.h" line="190"/>
        <source>Informazioni dettagliate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="32"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="33"/>
        <source>Codice a barre.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="34"/>
        <source>Titolo.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="35"/>
        <source>Descrizione.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="36"/>
        <source>Autore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="37"/>
        <source>Lingua</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="38"/>
        <source>Categoria</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="39"/>
        <source>Collocazione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="40"/>
        <source>Quantità</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="41"/>
        <source>Prezzo unitario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="42"/>
        <source>Prezzo senza iva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="43"/>
        <source>Prezzo con iva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="44"/>
        <source>Totale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="45"/>
        <source>Info editore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="46"/>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="79"/>
        <source>Cod. Art.: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="80"/>
        <source>Codice a barre: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="81"/>
        <source>Titolo: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="82"/>
        <source>Descrizione: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="83"/>
        <source>Autore: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="84"/>
        <source>Lingua: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="85"/>
        <source>Categoria libro: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="86"/>
        <source>Info editore: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="87"/>
        <source>Collocazione: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="88"/>
        <source>Prezzo unitario: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="89"/>
        <source>Prezzo senza iva: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="90"/>
        <source>Prezzo con iva: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="91"/>
        <source>Totale: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="103"/>
        <source>Quantità: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="111"/>
        <source>Impossibile cercare</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="128"/>
        <source>Impossibile instanziare la quantità di articoli presenti in magazzino...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="111"/>
        <location filename="../carico_mag.cpp" line="128"/>
        <location filename="../carico_mag.cpp" line="143"/>
        <location filename="../carico_mag.cpp" line="236"/>
        <location filename="../carico_mag.cpp" line="260"/>
        <location filename="../carico_mag.cpp" line="295"/>
        <source>LyLibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="143"/>
        <source>Impossibile instanziare il prezzo totale degli articoli presenti in magazzino...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="150"/>
        <source>Esporta CSV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="151"/>
        <source>CSV(*.csv);;Tutti i file(*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="236"/>
        <source>Selezionare una riga da esportare in csv...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="243"/>
        <source>Esporta PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="244"/>
        <source>Pdf Files(*.pdf);;Tutti i file(*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="260"/>
        <source>Selezionare una riga da esportare in pdf...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="277"/>
        <location filename="../carico_mag.cpp" line="313"/>
        <source>Lylibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="278"/>
        <source>Vuoi eliminare veramente 
 il record selezionato?....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="295"/>
        <source>Selezionare una riga da eliminare...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="314"/>
        <source>Impossibile eliminare 
 il record selezionato?....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../carico_mag.cpp" line="328"/>
        <source>Anteprima di stampa.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>causali</name>
    <message>
        <location filename="../ui/causali.ui" line="14"/>
        <location filename="../ui_causali.h" line="166"/>
        <source>Cusali di trasporto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/causali.ui" line="50"/>
        <location filename="../causali.cpp" line="173"/>
        <location filename="../ui_causali.h" line="167"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/causali.ui" line="57"/>
        <location filename="../causali.cpp" line="174"/>
        <location filename="../ui_causali.h" line="168"/>
        <source>Tipo di causale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/causali.ui" line="123"/>
        <location filename="../ui_causali.h" line="170"/>
        <source>Nuovo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/causali.ui" line="137"/>
        <location filename="../ui_causali.h" line="174"/>
        <source>Salva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/causali.ui" line="151"/>
        <location filename="../ui_causali.h" line="178"/>
        <source>Elimina</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/causali.ui" line="165"/>
        <location filename="../ui_causali.h" line="182"/>
        <source>Esci</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../causali.cpp" line="86"/>
        <location filename="../causali.cpp" line="102"/>
        <source>LyLibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../causali.cpp" line="86"/>
        <source>Impossibile inserire...
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../causali.cpp" line="102"/>
        <source>Impossibile aggiornare...
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../causali.cpp" line="129"/>
        <source>Errore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../causali.cpp" line="130"/>
        <source>Impossibile eliminare il record.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>check_database</name>
    <message>
        <location filename="../../check_database/check_database.ui" line="14"/>
        <location filename="../../check_database/ui_check_database.h" line="107"/>
        <source>check_database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../check_database/check_database.ui" line="42"/>
        <location filename="../../check_database/ui_check_database.h" line="108"/>
        <source>Analizza Database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../check_database/check_database.ui" line="53"/>
        <location filename="../../check_database/ui_check_database.h" line="109"/>
        <source>Correggi Database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../check_database/check_database.ui" line="64"/>
        <location filename="../../check_database/ui_check_database.h" line="110"/>
        <source>Chiudi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../check_database/check_database.ui" line="75"/>
        <location filename="../../check_database/ui_check_database.h" line="111"/>
        <source>Inserisci password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../check_database/check_database.cpp" line="10"/>
        <source>Analizza e ripara database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../check_database/check_database.cpp" line="42"/>
        <location filename="../../check_database/check_database.cpp" line="72"/>
        <source>Errore, impossbile avviare il servizio mysqlcheck...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../check_database/check_database.cpp" line="45"/>
        <source>Analizzazione tabelle in corso...

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../check_database/check_database.cpp" line="51"/>
        <source>Fine analizzazione...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../check_database/check_database.cpp" line="76"/>
        <source>Riparazione tabelle in corso...

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../check_database/check_database.cpp" line="82"/>
        <source>Fine riparazione...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>checkdatabase_plugin</name>
    <message>
        <location filename="../../check_database/checkdatabase_plugin.cpp" line="32"/>
        <source>Plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../check_database/checkdatabase_plugin.cpp" line="35"/>
        <source>Fix database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../check_database/checkdatabase_plugin.cpp" line="43"/>
        <source>Codelinsoft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../check_database/checkdatabase_plugin.cpp" line="51"/>
        <source>Strumento per la correzione degli errori del database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../check_database/checkdatabase_plugin.cpp" line="55"/>
        <source>Plugin Check Database</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cod_fisc</name>
    <message>
        <location filename="../ui/cod_fisc.ui" line="26"/>
        <location filename="../ui_cod_fisc.h" line="339"/>
        <source>Codice fiscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="80"/>
        <location filename="../ui_cod_fisc.h" line="348"/>
        <source>Calcolo codice fiscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="86"/>
        <location filename="../ui/cod_fisc.ui" line="227"/>
        <location filename="../ui_cod_fisc.h" line="349"/>
        <location filename="../ui_cod_fisc.h" line="375"/>
        <source>Cognome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="93"/>
        <location filename="../ui/cod_fisc.ui" line="220"/>
        <location filename="../ui_cod_fisc.h" line="350"/>
        <location filename="../ui_cod_fisc.h" line="372"/>
        <source>Nome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="100"/>
        <location filename="../ui_cod_fisc.h" line="351"/>
        <source>Sesso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="120"/>
        <location filename="../ui_cod_fisc.h" line="359"/>
        <source>F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="140"/>
        <location filename="../ui_cod_fisc.h" line="360"/>
        <source>Seleziona </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="147"/>
        <location filename="../ui_cod_fisc.h" line="361"/>
        <source>Comuni o Stato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="154"/>
        <location filename="../ui_cod_fisc.h" line="362"/>
        <source>Data di nascita</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="161"/>
        <location filename="../ui_cod_fisc.h" line="364"/>
        <source>Seleziona data di nascita</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="170"/>
        <location filename="../ui_cod_fisc.h" line="366"/>
        <source>dd/MM/yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="180"/>
        <location filename="../ui_cod_fisc.h" line="367"/>
        <source>Codice Fiscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="213"/>
        <location filename="../ui/cod_fisc.ui" line="234"/>
        <location filename="../ui_cod_fisc.h" line="369"/>
        <location filename="../ui_cod_fisc.h" line="378"/>
        <source>Seleziona comune o stato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="288"/>
        <location filename="../ui_cod_fisc.h" line="381"/>
        <source>Visualizza codice fiscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="340"/>
        <location filename="../ui_cod_fisc.h" line="388"/>
        <source>Cancella tutto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="360"/>
        <location filename="../ui_cod_fisc.h" line="392"/>
        <source>Calcola codice fiscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="399"/>
        <location filename="../ui_cod_fisc.h" line="396"/>
        <source>Visualizza anteprima codice fiscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="421"/>
        <location filename="../ui_cod_fisc.h" line="397"/>
        <source>F&amp;ile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="429"/>
        <location filename="../ui_cod_fisc.h" line="398"/>
        <source>Vis&amp;ualizza</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="435"/>
        <location filename="../ui_cod_fisc.h" line="399"/>
        <source>Esport&amp;a</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="446"/>
        <location filename="../ui_cod_fisc.h" line="340"/>
        <source>&amp;Esci</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="454"/>
        <location filename="../ui_cod_fisc.h" line="341"/>
        <source>&amp;Visualizza anteprima</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="459"/>
        <location filename="../ui_cod_fisc.h" line="342"/>
        <source>&amp;Stampa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="473"/>
        <location filename="../ui_cod_fisc.h" line="344"/>
        <source>&amp;Esporta in pdf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="478"/>
        <location filename="../ui_cod_fisc.h" line="345"/>
        <source>Esporta &amp;in immagine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="320"/>
        <location filename="../ui/cod_fisc.ui" line="323"/>
        <location filename="../ui_cod_fisc.h" line="384"/>
        <location filename="../ui_cod_fisc.h" line="386"/>
        <source>Esci</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="107"/>
        <location filename="../ui_cod_fisc.h" line="353"/>
        <source>Maschio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="110"/>
        <location filename="../ui_cod_fisc.h" line="355"/>
        <source>&amp;M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="117"/>
        <location filename="../ui_cod_fisc.h" line="357"/>
        <source>Femmina</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="343"/>
        <location filename="../ui_cod_fisc.h" line="390"/>
        <source>Cancella</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="363"/>
        <location filename="../ui_cod_fisc.h" line="394"/>
        <source>Calcola</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="468"/>
        <location filename="../ui_cod_fisc.h" line="343"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="487"/>
        <location filename="../ui_cod_fisc.h" line="346"/>
        <source>Verifica partita iva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/cod_fisc.ui" line="496"/>
        <location filename="../ui_cod_fisc.h" line="347"/>
        <source>Verifica codice fiscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cod_fisc.cpp" line="101"/>
        <source>Comuni</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cod_fisc.cpp" line="101"/>
        <source>Stati</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cod_fisc.cpp" line="604"/>
        <source>Inserisci il cognome
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cod_fisc.cpp" line="606"/>
        <source>Inserisci il nome
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cod_fisc.cpp" line="608"/>
        <source>Inserisci il sesso
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cod_fisc.cpp" line="612"/>
        <source>
Finisci di inserire i dati correttamente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cod_fisc.cpp" line="613"/>
        <source>Errore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cod_fisc.cpp" line="909"/>
        <source>Anteprima di stampa.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cod_fisc.cpp" line="956"/>
        <source>Esporta immagine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cod_fisc.cpp" line="957"/>
        <source>Images (*.png);;Tutti i file(*.*);;PNG(*.png)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cod_fisc.cpp" line="1016"/>
        <source>Esporta in PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cod_fisc.cpp" line="1017"/>
        <source>Pdf Files(*.pdf);;Tutti i file(*.*)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>connessione</name>
    <message>
        <location filename="../../initdb/connessione.ui" line="17"/>
        <location filename="../../initdb/ui_connessione.h" line="311"/>
        <source>Connessione al database Lyibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.ui" line="33"/>
        <location filename="../../initdb/ui_connessione.h" line="315"/>
        <source>Crea database locale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.ui" line="44"/>
        <location filename="../../initdb/ui_connessione.h" line="316"/>
        <source>Processo in corso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.ui" line="54"/>
        <location filename="../../initdb/ui_connessione.h" line="317"/>
        <source>Crea DB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.ui" line="144"/>
        <location filename="../../initdb/ui_connessione.h" line="319"/>
        <source>Creazione del Database Lylibrary per la prima installazione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.ui" line="151"/>
        <location filename="../../initdb/ui_connessione.h" line="320"/>
        <source>Password mysql</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.ui" line="192"/>
        <location filename="../../initdb/ui_connessione.h" line="322"/>
        <source>Connetti database in rete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.ui" line="200"/>
        <location filename="../../initdb/ui_connessione.h" line="323"/>
        <source>Indirizzo di rete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.ui" line="210"/>
        <location filename="../../initdb/ui_connessione.h" line="324"/>
        <source>Porta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.ui" line="231"/>
        <location filename="../../initdb/ui_connessione.h" line="325"/>
        <source>Nome database in rete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.ui" line="245"/>
        <location filename="../../initdb/ui_connessione.h" line="326"/>
        <source>Nome utente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.ui" line="255"/>
        <location filename="../../initdb/ui_connessione.h" line="327"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.ui" line="286"/>
        <location filename="../../initdb/ui_connessione.h" line="328"/>
        <source>Connetti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.ui" line="319"/>
        <location filename="../../initdb/ui_connessione.h" line="312"/>
        <source>Esci</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.ui" line="328"/>
        <location filename="../../initdb/ui_connessione.h" line="313"/>
        <source>Crea database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.ui" line="337"/>
        <location filename="../../initdb/ui_connessione.h" line="314"/>
        <source>Elimina database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.cpp" line="82"/>
        <source>Creazione database lylibrary effettuata....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.cpp" line="87"/>
        <source>Creazione database Lylibrary effettuata...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.cpp" line="122"/>
        <source>Creazione database locale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.cpp" line="124"/>
        <source>Configurazione database in corso...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.cpp" line="134"/>
        <location filename="../../initdb/connessione.cpp" line="194"/>
        <location filename="../../initdb/connessione.cpp" line="232"/>
        <source>Errore di connessione al DB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.cpp" line="135"/>
        <source>Controllare di aver installato Mysql e di aver creato il DB lylibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.cpp" line="136"/>
        <location filename="../../initdb/connessione.cpp" line="196"/>
        <location filename="../../initdb/connessione.cpp" line="234"/>
        <source>LyLibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.cpp" line="156"/>
        <source>Configurazione database completata con successo...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.cpp" line="162"/>
        <source>Lylibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.cpp" line="163"/>
        <source>Database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.cpp" line="164"/>
        <source>Creazione db strutturata con successo....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.cpp" line="195"/>
        <source>Verificare che i dati siano corretti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/connessione.cpp" line="233"/>
        <source>Impossibile connettersi al db.Controllare le impostazioni.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>db_bk_rs</name>
    <message>
        <location filename="../../backup_restore_db/db_bk_rs.ui" line="23"/>
        <location filename="../../utility/db_bk_rs.ui" line="23"/>
        <location filename="../../backup_restore_db/ui_db_bk_rs.h" line="166"/>
        <location filename="../../utility/ui_db_bk_rs.h" line="148"/>
        <source>Backup e ripristino database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../backup_restore_db/db_bk_rs.ui" line="45"/>
        <location filename="../../utility/db_bk_rs.ui" line="45"/>
        <location filename="../../backup_restore_db/ui_db_bk_rs.h" line="168"/>
        <location filename="../../utility/ui_db_bk_rs.h" line="150"/>
        <source>del tuo database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../backup_restore_db/db_bk_rs.ui" line="55"/>
        <location filename="../../utility/db_bk_rs.ui" line="55"/>
        <location filename="../../backup_restore_db/ui_db_bk_rs.h" line="169"/>
        <location filename="../../utility/ui_db_bk_rs.h" line="151"/>
        <source>Effettua il backup o restore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../backup_restore_db/db_bk_rs.ui" line="152"/>
        <location filename="../../utility/db_bk_rs.ui" line="152"/>
        <location filename="../../backup_restore_db/ui_db_bk_rs.h" line="171"/>
        <location filename="../../utility/ui_db_bk_rs.h" line="153"/>
        <source>Backup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../backup_restore_db/db_bk_rs.ui" line="176"/>
        <location filename="../../utility/db_bk_rs.ui" line="176"/>
        <location filename="../../backup_restore_db/ui_db_bk_rs.h" line="172"/>
        <location filename="../../utility/ui_db_bk_rs.h" line="154"/>
        <source>Ripristino</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../backup_restore_db/db_bk_rs.ui" line="187"/>
        <location filename="../../utility/db_bk_rs.ui" line="187"/>
        <location filename="../../backup_restore_db/ui_db_bk_rs.h" line="173"/>
        <location filename="../../utility/ui_db_bk_rs.h" line="155"/>
        <source>Esci</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../backup_restore_db/db_bk_rs.ui" line="198"/>
        <location filename="../../backup_restore_db/ui_db_bk_rs.h" line="174"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../backup_restore_db/db_bk_rs.cpp" line="41"/>
        <location filename="../../utility/db_bk_rs.cpp" line="36"/>
        <source>Save file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../backup_restore_db/db_bk_rs.cpp" line="41"/>
        <location filename="../../backup_restore_db/db_bk_rs.cpp" line="100"/>
        <source>Database(*.bkp);;Tutti i file(*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../backup_restore_db/db_bk_rs.cpp" line="45"/>
        <source>dd-MM-yyyy-hh-mm-ss</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../backup_restore_db/db_bk_rs.cpp" line="79"/>
        <location filename="../../backup_restore_db/db_bk_rs.cpp" line="87"/>
        <source>Backup database...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../backup_restore_db/db_bk_rs.cpp" line="80"/>
        <source>Backup database effettuato correttamente...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../backup_restore_db/db_bk_rs.cpp" line="88"/>
        <source>Backup database non effettuato correttamente...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../backup_restore_db/db_bk_rs.cpp" line="100"/>
        <location filename="../../utility/db_bk_rs.cpp" line="95"/>
        <source>Open file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../backup_restore_db/db_bk_rs.cpp" line="132"/>
        <location filename="../../backup_restore_db/db_bk_rs.cpp" line="141"/>
        <source>Ripristino database...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../backup_restore_db/db_bk_rs.cpp" line="133"/>
        <source>Ripristino del database effettuato correttamente...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../backup_restore_db/db_bk_rs.cpp" line="142"/>
        <source>Impossibile ripristinare il database...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dbbkrs_plugin</name>
    <message>
        <location filename="../../backup_restore_db/dbbkrs_plugin.cpp" line="33"/>
        <source>Plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../backup_restore_db/dbbkrs_plugin.cpp" line="36"/>
        <source>Backup and restore database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../backup_restore_db/dbbkrs_plugin.cpp" line="44"/>
        <source>Codelinsoft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../backup_restore_db/dbbkrs_plugin.cpp" line="52"/>
        <source>Strumento per il salvataggio e ripristino del database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../backup_restore_db/dbbkrs_plugin.cpp" line="56"/>
        <source>Plugin Backup and restore</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>details_plugin</name>
    <message>
        <location filename="../ui/details_plugin.ui" line="14"/>
        <location filename="../ui/details_plugin.ui" line="51"/>
        <location filename="../ui_details_plugin.h" line="189"/>
        <location filename="../ui_details_plugin.h" line="194"/>
        <source>Dettagli plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/details_plugin.ui" line="24"/>
        <location filename="../ui_details_plugin.h" line="191"/>
        <source>Esci</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/details_plugin.ui" line="27"/>
        <location filename="../ui_details_plugin.h" line="193"/>
        <source>Chiudi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/details_plugin.ui" line="57"/>
        <location filename="../ui_details_plugin.h" line="195"/>
        <source>Nome plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/details_plugin.ui" line="64"/>
        <location filename="../ui_details_plugin.h" line="196"/>
        <source>Avvio/Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/details_plugin.ui" line="71"/>
        <location filename="../ui_details_plugin.h" line="197"/>
        <source>Menu impostato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/details_plugin.ui" line="78"/>
        <location filename="../ui_details_plugin.h" line="198"/>
        <source>Nome visualizato del plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/details_plugin.ui" line="92"/>
        <location filename="../ui_details_plugin.h" line="200"/>
        <source>Versione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/details_plugin.ui" line="99"/>
        <location filename="../ui_details_plugin.h" line="201"/>
        <source>Autore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/details_plugin.ui" line="106"/>
        <location filename="../ui_details_plugin.h" line="202"/>
        <source>Licenza</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/details_plugin.ui" line="113"/>
        <location filename="../ui_details_plugin.h" line="203"/>
        <source>Descrizione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/details_plugin.ui" line="120"/>
        <location filename="../ui_details_plugin.h" line="204"/>
        <source>Icona</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/details_plugin.ui" line="191"/>
        <location filename="../ui_details_plugin.h" line="212"/>
        <source>GNU Lesser General Public License Usage

Alternatively, this plugin may be used under the terms of the GNU Lesser General Public License version 2.1 as published by the Free Software Foundation.  Please review the following information to ensure the GNU Lesser General Public License version 2.1 requirements will be met: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>esci</name>
    <message>
        <location filename="../ui/esci.ui" line="35"/>
        <location filename="../ui_esci.h" line="107"/>
        <source>Esci da LyLibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/esci.ui" line="57"/>
        <location filename="../ui_esci.h" line="108"/>
        <source>Sei sicuro di voler uscire?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/esci.ui" line="82"/>
        <location filename="../ui_esci.h" line="111"/>
        <source>Ritorna</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/esci.ui" line="85"/>
        <location filename="../ui_esci.h" line="113"/>
        <source>Cancella</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/esci.ui" line="112"/>
        <location filename="../ui/esci.ui" line="115"/>
        <location filename="../ui_esci.h" line="115"/>
        <location filename="../ui_esci.h" line="117"/>
        <source>Esci</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>export_inv</name>
    <message>
        <location filename="../../inventario/export_inv.cpp" line="152"/>
        <source>Inventario magazzino</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../inventario/export_inv.cpp" line="159"/>
        <source>Barcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../inventario/export_inv.cpp" line="162"/>
        <source>Titolo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../inventario/export_inv.cpp" line="165"/>
        <source>Quantità</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../inventario/export_inv.cpp" line="168"/>
        <source>Prezzo unitario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../inventario/export_inv.cpp" line="171"/>
        <location filename="../../inventario/export_inv.cpp" line="189"/>
        <source>Totale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../inventario/export_inv.cpp" line="183"/>
        <source>Imponibile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../inventario/export_inv.cpp" line="186"/>
        <source>Iva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../inventario/export_inv.cpp" line="213"/>
        <source>Pagina: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../inventario/export_inv.cpp" line="216"/>
        <source>Lylibrary - versione </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>fatt_acq</name>
    <message>
        <location filename="../ui/fatt_acq.ui" line="14"/>
        <location filename="../ui_fatt_acq.h" line="227"/>
        <source>Fatture acquisto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq.ui" line="33"/>
        <location filename="../ui_fatt_acq.h" line="228"/>
        <source>Totale fatture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq.ui" line="60"/>
        <location filename="../fatt_acq.cpp" line="331"/>
        <location filename="../ui_fatt_acq.h" line="229"/>
        <source>Totale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq.ui" line="144"/>
        <location filename="../ui_fatt_acq.h" line="232"/>
        <source>Cerca fattura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq.ui" line="160"/>
        <location filename="../ui_fatt_acq.h" line="234"/>
        <source>Nuova fattura di acquisto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq.ui" line="180"/>
        <location filename="../ui_fatt_acq.h" line="238"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Modifica fattura di acquisto&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq.ui" line="194"/>
        <location filename="../ui_fatt_acq.h" line="242"/>
        <source>Elimina</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq.ui" line="217"/>
        <location filename="../ui_fatt_acq.h" line="246"/>
        <source>Stampa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq.ui" line="237"/>
        <location filename="../ui_fatt_acq.h" line="250"/>
        <source>Chiudi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="38"/>
        <source>Cerca per ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="38"/>
        <source>Cerca per fornitore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="38"/>
        <source>Cerca per tipo fattura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="114"/>
        <location filename="../fatt_acq.cpp" line="238"/>
        <source>Lylibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="115"/>
        <source>Avviso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="116"/>
        <source>Inserisci il testo nella casella cerca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="160"/>
        <source>Le fatture d&apos;acquisto sono: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="164"/>
        <location filename="../fatt_acq.cpp" line="174"/>
        <location filename="../fatt_acq.cpp" line="189"/>
        <location filename="../fatt_acq.cpp" line="259"/>
        <location filename="../fatt_acq.cpp" line="306"/>
        <source>LyLibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="164"/>
        <location filename="../fatt_acq.cpp" line="174"/>
        <source>Inizializzazione fallita... </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="189"/>
        <source>Seleziona una riga da modificare...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="170"/>
        <source>Il totale delle fatture d&apos;acquisto è: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="239"/>
        <source>Vuoi eliminare veramente
 il record selezionato?....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="259"/>
        <source>Selezionare una riga da eliminare</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="280"/>
        <source>Errore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="281"/>
        <source>Impossibile eliminare il record.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="298"/>
        <source>Informazioni della fattura d&apos;acquisto: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="299"/>
        <source>ID:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="300"/>
        <source>Data: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="301"/>
        <source>Fornitore: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="302"/>
        <source>Tipo fattura: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="303"/>
        <source>Totale: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="306"/>
        <source>Impossibile cercare...
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="327"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="328"/>
        <source>Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="329"/>
        <source>Fornitore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="330"/>
        <source>Tipo fattura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq.cpp" line="349"/>
        <source>Anteprima di stampa.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>fatt_acq_art</name>
    <message>
        <location filename="../ui/fatt_acq_art.ui" line="14"/>
        <location filename="../ui_fatt_acq_art.h" line="489"/>
        <source>Inserisci fattura riga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq_art.ui" line="24"/>
        <location filename="../ui_fatt_acq_art.h" line="490"/>
        <source>Immagine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq_art.ui" line="37"/>
        <location filename="../ui_fatt_acq_art.h" line="492"/>
        <source>Inserisci immagine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq_art.ui" line="112"/>
        <location filename="../ui_fatt_acq_art.h" line="493"/>
        <source>Prezzo con iva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq_art.ui" line="122"/>
        <location filename="../ui_fatt_acq_art.h" line="494"/>
        <source>Quantità</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq_art.ui" line="129"/>
        <location filename="../ui_fatt_acq_art.h" line="495"/>
        <source>Prezzo senza iva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq_art.ui" line="139"/>
        <location filename="../ui_fatt_acq_art.h" line="496"/>
        <source>Sconto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq_art.ui" line="188"/>
        <location filename="../ui_fatt_acq_art.h" line="498"/>
        <source>Cod. Libro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq_art.ui" line="173"/>
        <location filename="../ui_fatt_acq_art.h" line="497"/>
        <source>Iva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq_art.ui" line="195"/>
        <location filename="../ui_fatt_acq_art.h" line="499"/>
        <source>Descizione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq_art.ui" line="202"/>
        <location filename="../ui_fatt_acq_art.h" line="500"/>
        <source>Info editore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq_art.ui" line="209"/>
        <location filename="../ui_fatt_acq_art.h" line="501"/>
        <source>Collocazione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq_art.ui" line="216"/>
        <location filename="../ui_fatt_acq_art.h" line="502"/>
        <source>Tipo di libro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq_art.ui" line="253"/>
        <location filename="../ui_fatt_acq_art.h" line="503"/>
        <source>Image dir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq_art.ui" line="263"/>
        <location filename="../ui_fatt_acq_art.h" line="504"/>
        <source>Cod. a barre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq_art.ui" line="270"/>
        <location filename="../ui_fatt_acq_art.h" line="505"/>
        <source>Totale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq_art.ui" line="285"/>
        <location filename="../ui/fatt_acq_art.ui" line="300"/>
        <location filename="../ui_fatt_acq_art.h" line="506"/>
        <location filename="../ui_fatt_acq_art.h" line="507"/>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq_art.ui" line="307"/>
        <location filename="../ui_fatt_acq_art.h" line="508"/>
        <source>UM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq_art.ui" line="341"/>
        <location filename="../ui_fatt_acq_art.h" line="509"/>
        <source>Lingua</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq_art.ui" line="362"/>
        <location filename="../ui_fatt_acq_art.h" line="510"/>
        <source>Titolo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq_art.ui" line="369"/>
        <location filename="../ui_fatt_acq_art.h" line="511"/>
        <source>Autore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq_art.ui" line="396"/>
        <location filename="../ui_fatt_acq_art.h" line="513"/>
        <source>Prezzo unitario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq_art.ui" line="415"/>
        <location filename="../ui_fatt_acq_art.h" line="516"/>
        <source>Aggiorna</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq_art.ui" line="429"/>
        <location filename="../ui_fatt_acq_art.h" line="520"/>
        <source>Esci</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_acq_art.ui" line="443"/>
        <location filename="../ui_fatt_acq_art.h" line="524"/>
        <source>Salva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq_art.cpp" line="42"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq_art.cpp" line="46"/>
        <source>Lylibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq_art.cpp" line="47"/>
        <source>Impossibile aprire %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq_art.cpp" line="80"/>
        <source>Articolo trovato...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq_art.cpp" line="99"/>
        <source>Articolo non trovato...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq_art.cpp" line="182"/>
        <source>La voce suddetta non si puo inserire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq_art.cpp" line="183"/>
        <source>Impossibile inserire </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq_art.cpp" line="219"/>
        <location filename="../fatt_acq_art.cpp" line="254"/>
        <location filename="../fatt_acq_art.cpp" line="287"/>
        <location filename="../fatt_acq_art.cpp" line="300"/>
        <location filename="../fatt_acq_art.cpp" line="314"/>
        <location filename="../fatt_acq_art.cpp" line="412"/>
        <location filename="../fatt_acq_art.cpp" line="454"/>
        <source>LyLibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq_art.cpp" line="219"/>
        <location filename="../fatt_acq_art.cpp" line="254"/>
        <source>Errore nell&apos;inserimento... </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq_art.cpp" line="287"/>
        <location filename="../fatt_acq_art.cpp" line="300"/>
        <location filename="../fatt_acq_art.cpp" line="314"/>
        <source>Impossibile visualizzare il prezzo senza iva... </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq_art.cpp" line="372"/>
        <source>Voce non aggiornabile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq_art.cpp" line="373"/>
        <source>Impossibile aggiornare </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_acq_art.cpp" line="412"/>
        <location filename="../fatt_acq_art.cpp" line="454"/>
        <source>Impossibile aggiornare... </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>fatt_new</name>
    <message>
        <location filename="../ui/fatt_new.ui" line="38"/>
        <location filename="../ui_fatt_new.h" line="423"/>
        <source>Dati fattura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_new.ui" line="51"/>
        <location filename="../ui_fatt_new.h" line="424"/>
        <source>Dati fattura di acquisto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_new.ui" line="59"/>
        <location filename="../ui_fatt_new.h" line="425"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_new.ui" line="69"/>
        <location filename="../ui_fatt_new.h" line="426"/>
        <source>Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_new.ui" line="79"/>
        <location filename="../ui_fatt_new.h" line="427"/>
        <source>Fornitore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_new.ui" line="93"/>
        <location filename="../ui_fatt_new.h" line="428"/>
        <source>Sconto 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_new.ui" line="103"/>
        <location filename="../ui_fatt_new.h" line="429"/>
        <source>Sconto 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_new.ui" line="113"/>
        <location filename="../ui_fatt_new.h" line="430"/>
        <source>Sconto 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_new.ui" line="123"/>
        <location filename="../ui_fatt_new.h" line="431"/>
        <source>Spese di trasporto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_new.ui" line="133"/>
        <location filename="../ui_fatt_new.h" line="432"/>
        <source>Spese di incasso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_new.ui" line="143"/>
        <location filename="../ui_fatt_new.h" line="433"/>
        <source>Tipo di pagamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_new.ui" line="200"/>
        <location filename="../ui_fatt_new.h" line="435"/>
        <source>Dati fattura esterna</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_new.ui" line="208"/>
        <location filename="../ui_fatt_new.h" line="436"/>
        <source>Numero fattura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_new.ui" line="222"/>
        <location filename="../ui_fatt_new.h" line="437"/>
        <source>Data fattura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_new.ui" line="232"/>
        <location filename="../ui_fatt_new.h" line="438"/>
        <source>Annotazioni fattura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_new.ui" line="260"/>
        <location filename="../ui_fatt_new.h" line="439"/>
        <source>Aggiungi riga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_new.ui" line="271"/>
        <location filename="../ui_fatt_new.h" line="440"/>
        <source>Modifica riga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_new.ui" line="340"/>
        <location filename="../ui_fatt_new.h" line="441"/>
        <source>Iva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_new.ui" line="354"/>
        <location filename="../fatt_new.cpp" line="534"/>
        <location filename="../ui_fatt_new.h" line="442"/>
        <source>Totale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_new.ui" line="375"/>
        <location filename="../ui_fatt_new.h" line="443"/>
        <source>Imponibile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_new.ui" line="382"/>
        <location filename="../ui_fatt_new.h" line="444"/>
        <source>Aggiorna totale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fatt_new.ui" line="433"/>
        <location filename="../ui_fatt_new.h" line="448"/>
        <source>Elimina riga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="123"/>
        <location filename="../fatt_new.cpp" line="182"/>
        <location filename="../fatt_new.cpp" line="185"/>
        <location filename="../fatt_new.cpp" line="251"/>
        <location filename="../fatt_new.cpp" line="254"/>
        <location filename="../fatt_new.cpp" line="295"/>
        <location filename="../fatt_new.cpp" line="349"/>
        <location filename="../fatt_new.cpp" line="564"/>
        <location filename="../fatt_new.cpp" line="573"/>
        <location filename="../fatt_new.cpp" line="583"/>
        <location filename="../fatt_new.cpp" line="603"/>
        <location filename="../fatt_new.cpp" line="612"/>
        <location filename="../fatt_new.cpp" line="622"/>
        <source>LyLibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="124"/>
        <source>Errore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="159"/>
        <source>La voce suddetta non si puo inserire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="160"/>
        <location filename="../fatt_new.cpp" line="185"/>
        <location filename="../fatt_new.cpp" line="254"/>
        <source>Impossibile inserire </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="182"/>
        <source>Inserimento effettuato correttamente...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="229"/>
        <source>La voce suddetta non si puo aggiornare</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="230"/>
        <source>Impossibile aggiornare </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="251"/>
        <source>Aggiornamento effettuato correttamente...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="55"/>
        <source>Inserisci articoli fattura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="125"/>
        <source>Impossibile inserire la fattura,
 poichè non hai inserito i dati correttamente...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="179"/>
        <location filename="../fatt_new.cpp" line="246"/>
        <location filename="../fatt_new.cpp" line="373"/>
        <source>Acquisti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="194"/>
        <source>Impossibile aggiornare la fattura,
 poichè non hai inserito i dati correttamente...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="276"/>
        <location filename="../fatt_new.cpp" line="314"/>
        <location filename="../fatt_new.cpp" line="631"/>
        <location filename="../fatt_new.cpp" line="669"/>
        <source>Lylibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="277"/>
        <source>Vuoi eliminare veramente 
 il record selezionato?....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="295"/>
        <source>Selezionare una riga da eliminare</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="315"/>
        <location filename="../fatt_new.cpp" line="670"/>
        <source>Impossibile eliminare 
 il record selezionato?....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="349"/>
        <source>Selezionare una riga da modificare...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="526"/>
        <source>Codice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="527"/>
        <source>Prodotto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="528"/>
        <source>Descrizione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="529"/>
        <source>Prezzo unitario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="530"/>
        <source>Prezzo S. IVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="531"/>
        <source>IVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="532"/>
        <source>Prezzo C. IVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="533"/>
        <source>Quantita&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="564"/>
        <location filename="../fatt_new.cpp" line="603"/>
        <source>Impossibile instanziare il prezzo senza iva... </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="573"/>
        <location filename="../fatt_new.cpp" line="612"/>
        <source>Impossibile instanziare l&apos;iva... </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="583"/>
        <location filename="../fatt_new.cpp" line="622"/>
        <source>Impossibile instanziare il totale... </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fatt_new.cpp" line="632"/>
        <source>Sei sicuro di voler uscire dalla fattura?
 I dati non verranno salvati....</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>fattura</name>
    <message>
        <location filename="../ui/fattura.ui" line="14"/>
        <location filename="../ui_fattura.h" line="255"/>
        <source>Fattura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura.ui" line="57"/>
        <location filename="../ui_fattura.h" line="259"/>
        <source>Stampa lista fatture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura.ui" line="77"/>
        <location filename="../ui_fattura.h" line="263"/>
        <source>Stampa fattura singola</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura.ui" line="207"/>
        <location filename="../ui_fattura.h" line="270"/>
        <source>Cerca fattura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura.ui" line="277"/>
        <location filename="../ui_fattura.h" line="272"/>
        <source>Totale fatture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura.ui" line="304"/>
        <location filename="../fattura.cpp" line="322"/>
        <location filename="../ui_fattura.h" line="273"/>
        <source>Totale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="45"/>
        <source>Cerca per ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="45"/>
        <source>Cerca per fornitore o cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="45"/>
        <source>Cerca per tipo fattura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="111"/>
        <location filename="../fattura.cpp" line="274"/>
        <source>Lylibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="112"/>
        <source>Avviso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="113"/>
        <source>Inserisci il testo nella casella cerca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="133"/>
        <source>Anteprima di stampa.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="187"/>
        <location filename="../fattura.cpp" line="251"/>
        <location filename="../fattura.cpp" line="261"/>
        <location filename="../fattura.cpp" line="306"/>
        <location filename="../fattura.cpp" line="348"/>
        <location filename="../fattura.cpp" line="366"/>
        <location filename="../fattura.cpp" line="402"/>
        <source>LyLibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="187"/>
        <source>Selezionare una riga da modificare...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="247"/>
        <source>Le fatture di vendita sono: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="251"/>
        <location filename="../fattura.cpp" line="261"/>
        <source>Impossibile ricavare le fatture di vendita...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="257"/>
        <source>Il totale delle fatture di vendita è: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="275"/>
        <source>Vuoi eliminare veramente 
 il record selezionato?....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="306"/>
        <source>Impossibile eliminare il record </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="318"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="319"/>
        <source>Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="320"/>
        <source>Fornitore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="321"/>
        <source>Tipo fattura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="340"/>
        <source>Informazioni della fattura di vendita: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="341"/>
        <source>ID:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="342"/>
        <source>Data: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="343"/>
        <source>Fornitore: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="344"/>
        <source>Tipo fattura: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="345"/>
        <source>Totale: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="348"/>
        <source>Impossibile trovare le informazioni...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="358"/>
        <source>Anteprima di stampa fattura libri.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="366"/>
        <source>Selezionare una fattura da stampare...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="385"/>
        <source>Esporta PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="386"/>
        <source>Pdf Files(*.pdf);;Tutti i file(*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura.cpp" line="402"/>
        <source>Selezionare una riga da esportare</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>fattura_rg</name>
    <message>
        <location filename="../ui/fattura_rg.ui" line="14"/>
        <location filename="../ui_fattura_rg.h" line="699"/>
        <source>Fattura di vendita</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="26"/>
        <location filename="../ui_fattura_rg.h" line="701"/>
        <source>Aggiorna fattura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="40"/>
        <location filename="../ui_fattura_rg.h" line="705"/>
        <source>Salva fattura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="54"/>
        <location filename="../ui_fattura_rg.h" line="709"/>
        <source>Chiudi senza salvare la fattura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="103"/>
        <location filename="../ui_fattura_rg.h" line="712"/>
        <source>Destinazione merce</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="109"/>
        <location filename="../ui_fattura_rg.h" line="713"/>
        <source>CAP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="123"/>
        <location filename="../ui_fattura_rg.h" line="715"/>
        <source>Località</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="137"/>
        <location filename="../ui_fattura_rg.h" line="717"/>
        <source>Prov.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="151"/>
        <location filename="../ui_fattura_rg.h" line="719"/>
        <source>Telefono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="178"/>
        <location filename="../ui_fattura_rg.h" line="721"/>
        <source>Fax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="192"/>
        <location filename="../ui_fattura_rg.h" line="723"/>
        <source>P. Iva/C. F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="206"/>
        <location filename="../ui_fattura_rg.h" line="725"/>
        <source>Indirizzo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="213"/>
        <location filename="../ui_fattura_rg.h" line="726"/>
        <source>Ragione sociale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="237"/>
        <location filename="../ui/fattura_rg.ui" line="243"/>
        <location filename="../ui_fattura_rg.h" line="729"/>
        <location filename="../ui_fattura_rg.h" line="730"/>
        <source>Banca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="281"/>
        <location filename="../ui_fattura_rg.h" line="731"/>
        <source>IBAN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="295"/>
        <location filename="../ui_fattura_rg.h" line="733"/>
        <source>Agente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="305"/>
        <location filename="../ui_fattura_rg.h" line="734"/>
        <source>Provvigione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="315"/>
        <location filename="../ui_fattura_rg.h" line="735"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:11pt; font-weight:600;&quot;&gt;%&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="322"/>
        <location filename="../ui_fattura_rg.h" line="737"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Inserisci Banca....&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="336"/>
        <location filename="../ui_fattura_rg.h" line="741"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Aggiorna lista banche....&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="396"/>
        <location filename="../ui_fattura_rg.h" line="744"/>
        <source>Iva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="434"/>
        <location filename="../fattura_rg.cpp" line="353"/>
        <location filename="../ui_fattura_rg.h" line="745"/>
        <source>Totale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="479"/>
        <location filename="../ui_fattura_rg.h" line="746"/>
        <source>Imponibile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="510"/>
        <location filename="../ui_fattura_rg.h" line="747"/>
        <source>Aggiorna totale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="550"/>
        <location filename="../ui_fattura_rg.h" line="749"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Inserisci cliente&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="553"/>
        <location filename="../ui_fattura_rg.h" line="751"/>
        <source>Dati fattura di vendita</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="585"/>
        <location filename="../ui_fattura_rg.h" line="754"/>
        <source>Note pagamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="595"/>
        <location filename="../ui_fattura_rg.h" line="755"/>
        <source>Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="602"/>
        <location filename="../ui_fattura_rg.h" line="756"/>
        <source>Vs Ordine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="612"/>
        <location filename="../ui_fattura_rg.h" line="757"/>
        <source>Sconto 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="559"/>
        <location filename="../ui_fattura_rg.h" line="752"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="632"/>
        <location filename="../ui_fattura_rg.h" line="758"/>
        <source>Sconto 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="639"/>
        <location filename="../ui_fattura_rg.h" line="759"/>
        <source>Pagamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="566"/>
        <location filename="../ui_fattura_rg.h" line="753"/>
        <source>Cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="646"/>
        <location filename="../ui_fattura_rg.h" line="760"/>
        <source>Spese trasporto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="697"/>
        <location filename="../ui_fattura_rg.h" line="761"/>
        <source>Annotazioni</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="704"/>
        <location filename="../ui_fattura_rg.h" line="762"/>
        <source>Spese incasso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="725"/>
        <location filename="../ui_fattura_rg.h" line="764"/>
        <source>Sconto 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="732"/>
        <location filename="../ui_fattura_rg.h" line="765"/>
        <source>Seleziona tipo cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="739"/>
        <location filename="../ui_fattura_rg.h" line="766"/>
        <source>Scadenze</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="875"/>
        <location filename="../ui/fattura_rg.ui" line="878"/>
        <location filename="../ui_fattura_rg.h" line="769"/>
        <location filename="../ui_fattura_rg.h" line="771"/>
        <source>Aggiungi riga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="889"/>
        <location filename="../ui/fattura_rg.ui" line="892"/>
        <location filename="../ui_fattura_rg.h" line="773"/>
        <location filename="../ui_fattura_rg.h" line="775"/>
        <source>Modifica riga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg.ui" line="903"/>
        <location filename="../ui/fattura_rg.ui" line="906"/>
        <location filename="../ui_fattura_rg.h" line="777"/>
        <location filename="../ui_fattura_rg.h" line="779"/>
        <source>Elimina riga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="47"/>
        <source>Inserisci cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="48"/>
        <source>Inserisci fornitore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="50"/>
        <source>Cliente </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="50"/>
        <source>Fornitore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="345"/>
        <source>Codice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="346"/>
        <source>Prodotto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="347"/>
        <source>Descrizione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="348"/>
        <source>Prezzo unitario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="349"/>
        <source>Prezzo S. IVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="350"/>
        <source>IVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="351"/>
        <source>Prezzo C. IVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="352"/>
        <source>Quantita&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="382"/>
        <source>Inserisci articoli fattura libri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="395"/>
        <location filename="../fattura_rg.cpp" line="492"/>
        <source>Impossibile inserire la fattura,
 poichè non hai inserito i dati correttamente...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="605"/>
        <location filename="../fattura_rg.cpp" line="653"/>
        <source>Vendita</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="393"/>
        <location filename="../fattura_rg.cpp" line="470"/>
        <location filename="../fattura_rg.cpp" line="490"/>
        <location filename="../fattura_rg.cpp" line="589"/>
        <location filename="../fattura_rg.cpp" line="592"/>
        <location filename="../fattura_rg.cpp" line="609"/>
        <location filename="../fattura_rg.cpp" line="612"/>
        <location filename="../fattura_rg.cpp" line="627"/>
        <location filename="../fattura_rg.cpp" line="707"/>
        <location filename="../fattura_rg.cpp" line="840"/>
        <location filename="../fattura_rg.cpp" line="849"/>
        <location filename="../fattura_rg.cpp" line="859"/>
        <location filename="../fattura_rg.cpp" line="933"/>
        <location filename="../fattura_rg.cpp" line="942"/>
        <location filename="../fattura_rg.cpp" line="952"/>
        <source>LyLibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="394"/>
        <location filename="../fattura_rg.cpp" line="491"/>
        <source>Errore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="470"/>
        <location filename="../fattura_rg.cpp" line="609"/>
        <source>Aggiornamento effettuato correttamente...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="474"/>
        <source>La voce suddetta non si puo aggiornare</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="475"/>
        <source>Impossibile aggiornare </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="565"/>
        <source>La voce suddetta non si puo inserire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="566"/>
        <location filename="../fattura_rg.cpp" line="592"/>
        <location filename="../fattura_rg.cpp" line="612"/>
        <source>Impossibile inserire </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="589"/>
        <source>Inserimento effettuato correttamente...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="627"/>
        <source>Selezionare una riga da modificare...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="688"/>
        <location filename="../fattura_rg.cpp" line="727"/>
        <location filename="../fattura_rg.cpp" line="869"/>
        <location filename="../fattura_rg.cpp" line="910"/>
        <source>Lylibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="689"/>
        <source>Vuoi eliminare veramente 
 il record selezionato?....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="707"/>
        <source>Selezionare una riga da eliminare</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="728"/>
        <location filename="../fattura_rg.cpp" line="911"/>
        <source>Impossibile eliminare 
 il record selezionato?....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="840"/>
        <location filename="../fattura_rg.cpp" line="933"/>
        <source>Impossibile instanziare il prezzo senza iva... </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="849"/>
        <location filename="../fattura_rg.cpp" line="942"/>
        <source>Impossibile instanziare l&apos;iva... </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="859"/>
        <location filename="../fattura_rg.cpp" line="952"/>
        <source>Impossibile instanziare il totale... </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg.cpp" line="870"/>
        <source>Sei sicuro di voler uscire dalla fattura?
 I dati non verranno salvati....</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>fattura_rg_art</name>
    <message>
        <location filename="../ui/fattura_rg_art.ui" line="26"/>
        <location filename="../ui_fattura_rg_art.h" line="489"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg_art.ui" line="97"/>
        <location filename="../ui_fattura_rg_art.h" line="490"/>
        <source>Prezzo con iva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg_art.ui" line="107"/>
        <location filename="../ui_fattura_rg_art.h" line="491"/>
        <source>Quantità</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg_art.ui" line="114"/>
        <location filename="../ui_fattura_rg_art.h" line="492"/>
        <source>Prezzo senza iva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg_art.ui" line="124"/>
        <location filename="../ui_fattura_rg_art.h" line="493"/>
        <source>Sconto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg_art.ui" line="163"/>
        <location filename="../ui_fattura_rg_art.h" line="495"/>
        <source>Cod. Libro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg_art.ui" line="148"/>
        <location filename="../ui_fattura_rg_art.h" line="494"/>
        <source>Iva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg_art.ui" line="170"/>
        <location filename="../ui_fattura_rg_art.h" line="496"/>
        <source>Descizione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg_art.ui" line="177"/>
        <location filename="../ui_fattura_rg_art.h" line="497"/>
        <source>Info editore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg_art.ui" line="184"/>
        <location filename="../ui_fattura_rg_art.h" line="498"/>
        <source>Scaffale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg_art.ui" line="191"/>
        <location filename="../ui_fattura_rg_art.h" line="499"/>
        <source>Tipo di libro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg_art.ui" line="228"/>
        <location filename="../ui_fattura_rg_art.h" line="500"/>
        <source>Image dir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg_art.ui" line="238"/>
        <location filename="../ui_fattura_rg_art.h" line="501"/>
        <source>Cod. a barre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg_art.ui" line="245"/>
        <location filename="../ui_fattura_rg_art.h" line="502"/>
        <source>Totale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg_art.ui" line="260"/>
        <location filename="../ui/fattura_rg_art.ui" line="275"/>
        <location filename="../ui_fattura_rg_art.h" line="503"/>
        <location filename="../ui_fattura_rg_art.h" line="504"/>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg_art.ui" line="282"/>
        <location filename="../ui_fattura_rg_art.h" line="505"/>
        <source>UM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg_art.ui" line="326"/>
        <location filename="../ui_fattura_rg_art.h" line="506"/>
        <source>Lingua</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg_art.ui" line="347"/>
        <location filename="../ui_fattura_rg_art.h" line="507"/>
        <source>Libro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg_art.ui" line="354"/>
        <location filename="../ui_fattura_rg_art.h" line="508"/>
        <source>Autore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg_art.ui" line="381"/>
        <location filename="../ui_fattura_rg_art.h" line="510"/>
        <source>Prezzo unitario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg_art.ui" line="394"/>
        <location filename="../ui_fattura_rg_art.h" line="511"/>
        <source>Immagine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg_art.ui" line="407"/>
        <location filename="../ui_fattura_rg_art.h" line="513"/>
        <source>Inserisci immagine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg_art.ui" line="434"/>
        <location filename="../ui_fattura_rg_art.h" line="517"/>
        <source>Esci</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fattura_rg_art.ui" line="448"/>
        <location filename="../ui_fattura_rg_art.h" line="521"/>
        <source>Salva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg_art.cpp" line="105"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg_art.cpp" line="109"/>
        <source>Lylibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg_art.cpp" line="110"/>
        <source>Impossibile aprire %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg_art.cpp" line="223"/>
        <source>Articolo trovato...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg_art.cpp" line="242"/>
        <source>Articolo non trovato...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg_art.cpp" line="344"/>
        <location filename="../fattura_rg_art.cpp" line="357"/>
        <location filename="../fattura_rg_art.cpp" line="370"/>
        <location filename="../fattura_rg_art.cpp" line="498"/>
        <location filename="../fattura_rg_art.cpp" line="595"/>
        <location filename="../fattura_rg_art.cpp" line="637"/>
        <location filename="../fattura_rg_art.cpp" line="679"/>
        <source>LyLibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg_art.cpp" line="344"/>
        <location filename="../fattura_rg_art.cpp" line="357"/>
        <location filename="../fattura_rg_art.cpp" line="370"/>
        <source>Impossibile visualizzare il prezzo senza iva... </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg_art.cpp" line="455"/>
        <source>La voce suddetta non si puo inserire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg_art.cpp" line="456"/>
        <source>Impossibile inserire </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg_art.cpp" line="498"/>
        <source>Errore nell&apos;inserimento... </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg_art.cpp" line="555"/>
        <source>Voce non aggiornabile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg_art.cpp" line="556"/>
        <source>Impossibile aggiornare </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fattura_rg_art.cpp" line="595"/>
        <location filename="../fattura_rg_art.cpp" line="637"/>
        <location filename="../fattura_rg_art.cpp" line="679"/>
        <source>Impossibile aggiornare... </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>find_cap_italian</name>
    <message>
        <location filename="../ui/find_cap_italian.ui" line="20"/>
        <location filename="../ui_find_cap_italian.h" line="133"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/find_cap_italian.ui" line="26"/>
        <location filename="../ui_find_cap_italian.h" line="134"/>
        <source>Cerca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/find_cap_italian.ui" line="37"/>
        <location filename="../ui_find_cap_italian.h" line="135"/>
        <source>Esci</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/find_cap_italian.ui" line="61"/>
        <location filename="../ui_find_cap_italian.h" line="136"/>
        <source>Cerca CAP( Codici avviamento postali )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/find_cap_italian.ui" line="73"/>
        <location filename="../ui_find_cap_italian.h" line="137"/>
        <source>Seleziona comune</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../find_cap_italian.cpp" line="14"/>
        <source>Cerca CAP</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>fornitori</name>
    <message>
        <location filename="../ui/fornitori.ui" line="14"/>
        <location filename="../ui_fornitori.h" line="320"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fornitori.ui" line="36"/>
        <location filename="../fornitori.cpp" line="306"/>
        <location filename="../ui_fornitori.h" line="322"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fornitori.ui" line="50"/>
        <location filename="../fornitori.cpp" line="307"/>
        <location filename="../ui_fornitori.h" line="323"/>
        <source>Ragione sociale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fornitori.ui" line="60"/>
        <location filename="../ui_fornitori.h" line="324"/>
        <source>P.Iva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fornitori.ui" line="70"/>
        <location filename="../ui_fornitori.h" line="325"/>
        <source>C.F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fornitori.ui" line="80"/>
        <location filename="../fornitori.cpp" line="310"/>
        <location filename="../ui_fornitori.h" line="326"/>
        <source>Indirizzo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fornitori.ui" line="90"/>
        <location filename="../fornitori.cpp" line="311"/>
        <location filename="../ui_fornitori.h" line="327"/>
        <source>CAP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fornitori.ui" line="100"/>
        <location filename="../fornitori.cpp" line="312"/>
        <location filename="../ui_fornitori.h" line="328"/>
        <source>Località</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fornitori.ui" line="110"/>
        <location filename="../fornitori.cpp" line="313"/>
        <location filename="../ui_fornitori.h" line="329"/>
        <source>PROV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fornitori.ui" line="120"/>
        <location filename="../fornitori.cpp" line="314"/>
        <location filename="../ui_fornitori.h" line="330"/>
        <source>Telefono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fornitori.ui" line="130"/>
        <location filename="../ui_fornitori.h" line="331"/>
        <source>Fax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fornitori.ui" line="140"/>
        <location filename="../fornitori.cpp" line="316"/>
        <location filename="../ui_fornitori.h" line="332"/>
        <source>E-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fornitori.ui" line="150"/>
        <location filename="../fornitori.cpp" line="317"/>
        <location filename="../ui_fornitori.h" line="333"/>
        <source>Sito web</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fornitori.ui" line="230"/>
        <location filename="../ui_fornitori.h" line="336"/>
        <source>Nuovo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fornitori.ui" line="250"/>
        <location filename="../ui_fornitori.h" line="340"/>
        <source>Elimina</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fornitori.ui" line="270"/>
        <location filename="../ui_fornitori.h" line="344"/>
        <source>Salva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fornitori.ui" line="290"/>
        <location filename="../ui_fornitori.h" line="348"/>
        <source>Stampa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/fornitori.ui" line="310"/>
        <location filename="../ui_fornitori.h" line="352"/>
        <source>Esci</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fornitori.cpp" line="20"/>
        <source>Anagrafica fornitori</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fornitori.cpp" line="67"/>
        <location filename="../fornitori.cpp" line="179"/>
        <source>LyLibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fornitori.cpp" line="67"/>
        <source>Inserisci correttamente i dati</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fornitori.cpp" line="179"/>
        <source>Selezionare una riga da eliminare...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fornitori.cpp" line="224"/>
        <source>Errore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fornitori.cpp" line="225"/>
        <source>Impossibile eliminare record poichè non hai selezionato nulla</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fornitori.cpp" line="308"/>
        <source>Partita IVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fornitori.cpp" line="309"/>
        <source>Codice Fiscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fornitori.cpp" line="315"/>
        <source>FAX</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>inventario</name>
    <message>
        <location filename="../../inventario/inventario.ui" line="20"/>
        <location filename="../../inventario/ui_inventario.h" line="71"/>
        <source>Inventario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../inventario/inventario.ui" line="42"/>
        <location filename="../../inventario/ui_inventario.h" line="72"/>
        <source>Stampa
Inventario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../inventario/inventario.ui" line="74"/>
        <location filename="../../inventario/ui_inventario.h" line="74"/>
        <source>Esporta 
inventario
 in pdf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../inventario/inventario.cpp" line="38"/>
        <source>Esporta PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../inventario/inventario.cpp" line="39"/>
        <source>*.pdf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../inventario/inventario.cpp" line="39"/>
        <source>Pdf Files(*.pdf);;Tutti i file(*.*)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>inventario_plugin</name>
    <message>
        <location filename="../../inventario/inventario_plugin.cpp" line="33"/>
        <source>Plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../inventario/inventario_plugin.cpp" line="36"/>
        <source>Product inventory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../inventario/inventario_plugin.cpp" line="44"/>
        <source>Codelinsoft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../inventario/inventario_plugin.cpp" line="52"/>
        <source>Inventario dei prodotti presenti in magazzino</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../inventario/inventario_plugin.cpp" line="56"/>
        <source>Plugin Inventario</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>iva</name>
    <message>
        <location filename="../ui/iva.ui" line="14"/>
        <location filename="../ui/iva.ui" line="64"/>
        <location filename="../iva.cpp" line="47"/>
        <location filename="../ui_iva.h" line="173"/>
        <location filename="../ui_iva.h" line="176"/>
        <source>Iva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/iva.ui" line="57"/>
        <location filename="../iva.cpp" line="46"/>
        <location filename="../ui_iva.h" line="175"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/iva.ui" line="74"/>
        <location filename="../ui_iva.h" line="177"/>
        <source>Descrizione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iva.cpp" line="48"/>
        <source>Descizione.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iva.cpp" line="87"/>
        <location filename="../iva.cpp" line="184"/>
        <source>LyLibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iva.cpp" line="87"/>
        <source>Inserisci correttamente i dati</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iva.cpp" line="142"/>
        <source>Impossibile aggiornare 
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iva.cpp" line="172"/>
        <source>Impossibile inserire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iva.cpp" line="184"/>
        <source>Selezionare una riga da eliminare...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>license</name>
    <message>
        <location filename="../../log_man/license.ui" line="14"/>
        <location filename="../../log_man/ui_license.h" line="184"/>
        <source>license</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../log_man/license.ui" line="57"/>
        <location filename="../../log_man/ui_license.h" line="186"/>
        <source>Indietro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../log_man/license.ui" line="64"/>
        <location filename="../../log_man/ui_license.h" line="187"/>
        <source>Avanti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../log_man/license.ui" line="71"/>
        <location filename="../../log_man/ui_license.h" line="188"/>
        <source>Fine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../log_man/license.ui" line="91"/>
        <location filename="../../log_man/ui_license.h" line="190"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;GNU LESSER GENERAL PUBLIC LICENSE&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;                       Version 3, 29 June 2007&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt; Copyright (C) 2007 Free Software Foundation, Inc. &amp;lt;http://fsf.org/&amp;gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt; Everyone is permitted to copy and distribute verbatim copies&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt; of this license document, but changing it is not allowed.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;  This version of the GNU Lesser General Public License incorporates&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;the terms and conditions of version 3 of the GNU General Public&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;License, supplemented by the additional permissions listed below.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;  0. Additional Definitions.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;  As used herein, &amp;quot;this License&amp;quot; refers to version 3 of the GNU Lesser&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;General Public License, and the &amp;quot;GNU GPL&amp;quot; refers to version 3 of the GNU&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;General Public License.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;  &amp;quot;The Library&amp;quot; refers to a covered work governed by this License,&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;other than an Application or a Combined Work as defined below.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;  An &amp;quot;Application&amp;quot; is any work that makes use of an interface provided&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;by the Library, but which is not otherwise based on the Library.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Defining a subclass of a class defined by the Library is deemed a mode&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;of using an interface provided by the Library.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;  A &amp;quot;Combined Work&amp;quot; is a work produced by combining or linking an&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Application with the Library.  The particular version of the Library&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;with which the Combined Work was made is also called the &amp;quot;Linked&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Version&amp;quot;.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;  The &amp;quot;Minimal Corresponding Source&amp;quot; for a Combined Work means the&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Corresponding Source for the Combined Work, excluding any source code&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;for portions of the Combined Work that, considered in isolation, are&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;based on the Application, and not on the Linked Version.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;  The &amp;quot;Corresponding Application Code&amp;quot; for a Combined Work means the&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;object code and/or source code for the Application, including any data&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;and utility programs needed for reproducing the Combined Work from the&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Application, but excluding the System Libraries of the Combined Work.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;  1. Exception to Section 3 of the GNU GPL.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;  You may convey a covered work under sections 3 and 4 of this License&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;without being bound by section 3 of the GNU GPL.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;  2. Conveying Modified Versions.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;  If you modify a copy of the Library, and, in your modifications, a&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;facility refers to a function or data to be supplied by an Application&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;that uses the facility (other than as an argument passed when the&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;facility is invoked), then you may convey a copy of the modified&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;version:&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   a) under this License, provided that you make a good faith effort to&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   ensure that, in the event an Application does not supply the&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   function or data, the facility still operates, and performs&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   whatever part of its purpose remains meaningful, or&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   b) under the GNU GPL, with none of the additional permissions of&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   this License applicable to that copy.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;  3. Object Code Incorporating Material from Library Header Files.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;  The object code form of an Application may incorporate material from&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;a header file that is part of the Library.  You may convey such object&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;code under terms of your choice, provided that, if the incorporated&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;material is not limited to numerical parameters, data structure&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;layouts and accessors, or small macros, inline functions and templates&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;(ten or fewer lines in length), you do both of the following:&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   a) Give prominent notice with each copy of the object code that the&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   Library is used in it and that the Library and its use are&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   covered by this License.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   b) Accompany the object code with a copy of the GNU GPL and this license&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   document.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;  4. Combined Works.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;  You may convey a Combined Work under terms of your choice that,&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;taken together, effectively do not restrict modification of the&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;portions of the Library contained in the Combined Work and reverse&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;engineering for debugging such modifications, if you also do each of&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;the following:&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   a) Give prominent notice with each copy of the Combined Work that&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   the Library is used in it and that the Library and its use are&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   covered by this License.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   b) Accompany the Combined Work with a copy of the GNU GPL and this license&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   document.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   c) For a Combined Work that displays copyright notices during&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   execution, include the copyright notice for the Library among&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   these notices, as well as a reference directing the user to the&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   copies of the GNU GPL and this license document.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   d) Do one of the following:&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;       0) Convey the Minimal Corresponding Source under the terms of this&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;       License, and the Corresponding Application Code in a form&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;       suitable for, and under terms that permit, the user to&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;       recombine or relink the Application with a modified version of&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;       the Linked Version to produce a modified Combined Work, in the&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;       manner specified by section 6 of the GNU GPL for conveying&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;       Corresponding Source.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;       1) Use a suitable shared library mechanism for linking with the&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;       Library.  A suitable mechanism is one that (a) uses at run time&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;       a copy of the Library already present on the user&apos;s computer&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;       system, and (b) will operate properly with a modified version&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;       of the Library that is interface-compatible with the Linked&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;       Version.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   e) Provide Installation Information, but only if you would otherwise&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   be required to provide such information under section 6 of the&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   GNU GPL, and only to the extent that such information is&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   necessary to install and execute a modified version of the&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   Combined Work produced by recombining or relinking the&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   Application with a modified version of the Linked Version. (If&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   you use option 4d0, the Installation Information must accompany&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   the Minimal Corresponding Source and Corresponding Application&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   Code. If you use option 4d1, you must provide the Installation&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   Information in the manner specified by section 6 of the GNU GPL&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   for conveying Corresponding Source.)&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;  5. Combined Libraries.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;  You may place library facilities that are a work based on the&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Library side by side in a single library together with other library&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;facilities that are not Applications and are not covered by this&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;License, and convey such a combined library under terms of your&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;choice, if you do both of the following:&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   a) Accompany the combined library with a copy of the same work based&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   on the Library, uncombined with any other library facilities,&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   conveyed under the terms of this License.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   b) Give prominent notice with the combined library that part of it&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   is a work based on the Library, and explaining where to find the&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;   accompanying uncombined form of the same work.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;  6. Revised Versions of the GNU Lesser General Public License.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;  The Free Software Foundation may publish revised and/or new versions&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;of the GNU Lesser General Public License from time to time. Such new&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;versions will be similar in spirit to the present version, but may&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;differ in detail to address new problems or concerns.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;  Each version is given a distinguishing version number. If the&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Library as you received it specifies that a certain numbered version&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;of the GNU Lesser General Public License &amp;quot;or any later version&amp;quot;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;applies to it, you have the option of following the terms and&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;conditions either of that published version or of any later version&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;published by the Free Software Foundation. If the Library as you&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;received it does not specify a version number of the GNU Lesser&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;General Public License, you may choose any version of the GNU Lesser&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;General Public License ever published by the Free Software Foundation.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;  If the Library as you received it specifies that a proxy can decide&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;whether future versions of the GNU Lesser General Public License shall&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;apply, that proxy&apos;s public statement of acceptance of any version is&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;permanent authorization for you to choose that version for the&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Library.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../log_man/license.ui" line="267"/>
        <location filename="../../log_man/ui_license.h" line="389"/>
        <source>Accetto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../log_man/license.ui" line="287"/>
        <location filename="../../log_man/ui_license.h" line="390"/>
        <source>Non accetto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../log_man/license.ui" line="307"/>
        <location filename="../../log_man/ui_license.h" line="392"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Droid Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Congratulazioni hai scelto la versione professional.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Grazie per averci preferito.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Per ulteriori informazioni consulta il nostro sito web:&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;www.codelinsoft.it&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#4582be;&quot;&gt;www.codelinsoft.it&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; color:#4582be;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;oppure contattaci al seguente indirizzo email:&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;mailto:info@codelinsoft.it&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#4582be;&quot;&gt;info@codelinsoft.it&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../log_man/license.cpp" line="29"/>
        <source>Configurazione di avvio Lylibrary</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>pag</name>
    <message>
        <location filename="../ui/pag.ui" line="14"/>
        <location filename="../ui_pag.h" line="197"/>
        <source>Anagrafica pagamenti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pag.ui" line="57"/>
        <location filename="../pag.cpp" line="92"/>
        <location filename="../ui_pag.h" line="199"/>
        <source>Codice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pag.ui" line="71"/>
        <location filename="../pag.cpp" line="93"/>
        <location filename="../ui_pag.h" line="200"/>
        <source>Descrizione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pag.ui" line="88"/>
        <location filename="../ui_pag.h" line="201"/>
        <source>Nota su fattura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pag.cpp" line="33"/>
        <location filename="../pag.cpp" line="132"/>
        <source>LyLibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pag.cpp" line="33"/>
        <source>Inserisci correttamente i dati</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pag.cpp" line="63"/>
        <location filename="../pag.cpp" line="169"/>
        <location filename="../pag.cpp" line="200"/>
        <source>Errore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pag.cpp" line="64"/>
        <location filename="../pag.cpp" line="201"/>
        <source>Impossibile aggiornare</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pag.cpp" line="94"/>
        <source>Nota su Fattura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pag.cpp" line="132"/>
        <source>Selezionare una riga da eliminare...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pag.cpp" line="170"/>
        <source>Impossibile eliminare record poichè non hai selezionato nulla</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>pluginmanager</name>
    <message>
        <location filename="../ui/pluginmanager.ui" line="14"/>
        <location filename="../ui_pluginmanager.h" line="193"/>
        <source>Gestione plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pluginmanager.ui" line="205"/>
        <location filename="../ui_pluginmanager.h" line="220"/>
        <source>Dettagli plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pluginmanager.ui" line="245"/>
        <location filename="../ui_pluginmanager.h" line="226"/>
        <source>Nome plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pluginmanager.ui" line="250"/>
        <location filename="../ui_pluginmanager.h" line="225"/>
        <source>Avvia/Disattiva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pluginmanager.ui" line="255"/>
        <location filename="../ui_pluginmanager.h" line="224"/>
        <source>Versione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pluginmanager.ui" line="260"/>
        <location filename="../ui_pluginmanager.h" line="223"/>
        <source>Produttore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pluginmanager.ui" line="45"/>
        <location filename="../ui_pluginmanager.h" line="195"/>
        <source>Descrizione plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pluginmanager.ui" line="164"/>
        <location filename="../ui_pluginmanager.h" line="213"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Helvetica&apos;; font-size:10pt; font-weight:600; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:400;&quot;&gt;Nome:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pluginmanager.ui" line="62"/>
        <location filename="../ui_pluginmanager.h" line="196"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Helvetica&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Autore:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pluginmanager.ui" line="91"/>
        <location filename="../ui_pluginmanager.h" line="202"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Helvetica&apos;; font-size:10pt; font-weight:600; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:400;&quot;&gt;Versione:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pluginmanager.ui" line="113"/>
        <location filename="../ui_pluginmanager.h" line="207"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Helvetica&apos;; font-size:10pt; font-weight:600; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:400;&quot;&gt;Descrizione:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pluginmanager.ui" line="136"/>
        <location filename="../ui_pluginmanager.h" line="212"/>
        <source>Chiudi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pluginmanager.cpp" line="67"/>
        <source>Avviato...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pluginmanager.cpp" line="74"/>
        <source>Disattivato...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>porto</name>
    <message>
        <location filename="../ui/categoria.ui" line="14"/>
        <location filename="../ui_categoria.h" line="177"/>
        <source>Anagrafica categorie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/categoria.ui" line="54"/>
        <location filename="../categoria.cpp" line="245"/>
        <location filename="../ui_categoria.h" line="179"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/categoria.ui" line="89"/>
        <location filename="../ui_categoria.h" line="186"/>
        <source>Categoria</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/categoria.ui" line="68"/>
        <location filename="../ui_categoria.h" line="180"/>
        <source>Cerca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/categoria.ui" line="76"/>
        <location filename="../ui_categoria.h" line="183"/>
        <source>Cerca per categoria</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/categoria.ui" line="81"/>
        <location filename="../ui_categoria.h" line="184"/>
        <source>Cerca per ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/categoria.ui" line="144"/>
        <location filename="../categoria.cpp" line="329"/>
        <location filename="../ui_categoria.h" line="189"/>
        <source>Nuovo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/categoria.ui" line="158"/>
        <location filename="../categoria.cpp" line="332"/>
        <location filename="../ui_categoria.h" line="193"/>
        <source>Salva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/categoria.ui" line="172"/>
        <location filename="../categoria.cpp" line="326"/>
        <location filename="../ui_categoria.h" line="197"/>
        <source>Elimina</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/categoria.ui" line="186"/>
        <location filename="../ui_categoria.h" line="201"/>
        <source>Esci </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../categoria.cpp" line="23"/>
        <source>Ctrl+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../categoria.cpp" line="25"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../categoria.cpp" line="28"/>
        <source>Ctrl+D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../categoria.cpp" line="32"/>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../categoria.cpp" line="102"/>
        <source>Inserisci il testo nella casella cerca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../categoria.cpp" line="123"/>
        <location filename="../categoria.cpp" line="141"/>
        <source>LyLibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../categoria.cpp" line="123"/>
        <source>Inserisci correttamente i dati</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../categoria.cpp" line="141"/>
        <source>Impossibile aggiornare...
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../categoria.cpp" line="164"/>
        <location filename="../categoria.cpp" line="195"/>
        <location filename="../categoria.cpp" line="203"/>
        <source>Errore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../categoria.cpp" line="165"/>
        <source>Impossibile inserire...
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../categoria.cpp" line="196"/>
        <source>Impossibile eliminare...
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../categoria.cpp" line="204"/>
        <source>Seleziona una riga per eliminarla...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../categoria.cpp" line="246"/>
        <source>Tipo di categoria</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../categoria.cpp" line="323"/>
        <source>Chiudi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../categoria.cpp" line="335"/>
        <source>Aggiorna</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>pref</name>
    <message>
        <location filename="../ui/pref.ui" line="17"/>
        <location filename="../ui_pref.h" line="601"/>
        <source>Preferenze</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="65"/>
        <location filename="../ui_pref.h" line="602"/>
        <source>Impostazioni generali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="77"/>
        <location filename="../ui_pref.h" line="603"/>
        <source>Seleziona lingua</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="92"/>
        <location filename="../ui_pref.h" line="604"/>
        <source>Seleziona la lingua</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="99"/>
        <location filename="../ui_pref.h" line="605"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;La selezione della lingua richiede il riavvio...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="115"/>
        <location filename="../ui_pref.h" line="606"/>
        <source>Editor Fonts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="129"/>
        <location filename="../ui/pref.ui" line="203"/>
        <location filename="../ui_pref.h" line="607"/>
        <location filename="../ui_pref.h" line="610"/>
        <source>Font Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="161"/>
        <location filename="../ui/pref.ui" line="221"/>
        <location filename="../ui_pref.h" line="608"/>
        <location filename="../ui_pref.h" line="611"/>
        <source>Font Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="195"/>
        <location filename="../ui_pref.h" line="609"/>
        <source>Application Fonts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="249"/>
        <location filename="../ui_pref.h" line="612"/>
        <source>Seleziona tema software</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="290"/>
        <location filename="../ui_pref.h" line="613"/>
        <source>Seleziona tema</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="340"/>
        <location filename="../ui_pref.h" line="615"/>
        <source>Connetti database in rete </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="346"/>
        <location filename="../ui_pref.h" line="616"/>
        <source>Indirizzo IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="356"/>
        <location filename="../ui_pref.h" line="617"/>
        <source>Porta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="373"/>
        <location filename="../pref.cpp" line="175"/>
        <location filename="../pref.cpp" line="527"/>
        <location filename="../ui_pref.h" line="618"/>
        <source>Database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="416"/>
        <location filename="../ui_pref.h" line="620"/>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="426"/>
        <location filename="../ui_pref.h" line="621"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="442"/>
        <location filename="../ui_pref.h" line="622"/>
        <source>Connetti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="480"/>
        <location filename="../pref.cpp" line="181"/>
        <location filename="../pref.cpp" line="410"/>
        <location filename="../ui_pref.h" line="623"/>
        <source>Aggiornamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="494"/>
        <location filename="../ui_pref.h" line="624"/>
        <source>Abilita aggiornamenti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="524"/>
        <location filename="../ui_pref.h" line="625"/>
        <source>Disabilita aggiornamenti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="571"/>
        <location filename="../ui_pref.h" line="626"/>
        <source>Aggiorna</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="630"/>
        <location filename="../ui_pref.h" line="628"/>
        <source>Impostazioni fattura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="636"/>
        <location filename="../ui_pref.h" line="629"/>
        <source>Apri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="647"/>
        <location filename="../ui_pref.h" line="630"/>
        <source>Testata fattura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="667"/>
        <location filename="../ui_pref.h" line="631"/>
        <source>Opzioni logo fattura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="675"/>
        <location filename="../ui_pref.h" line="632"/>
        <source>Anteprima logo fattura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="732"/>
        <location filename="../ui_pref.h" line="633"/>
        <source>Chiudi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/pref.ui" line="773"/>
        <location filename="../ui_pref.h" line="634"/>
        <source>Applica</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="169"/>
        <source>Impostazioni
generali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="187"/>
        <source>Impostazioni
fattura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="202"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="203"/>
        <source>Images (*.png *.xpm *.jpg *.bmp);;Tutti i file(*.*);;JPG(*.jpg);;PNG(*.png);;BMP(*.bmp);;XPM(*.xpm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="207"/>
        <location filename="../pref.cpp" line="247"/>
        <location filename="../pref.cpp" line="409"/>
        <location filename="../pref.cpp" line="431"/>
        <location filename="../pref.cpp" line="477"/>
        <location filename="../pref.cpp" line="513"/>
        <source>LyLibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="208"/>
        <source>Impossibile aprire %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="232"/>
        <source>Salva le immagini</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="234"/>
        <source>Images (*.png);;Tutti i file(*.*);;PNG(*.png)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="248"/>
        <source>Impossibile scrivere %1: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="269"/>
        <source>Ridimensiona immagine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="276"/>
        <source>Larghezza logo </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="276"/>
        <source> px
Altezza logo     </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="280"/>
        <source>Salva immagine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="300"/>
        <source>Media</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="305"/>
        <source>Bilineare</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="411"/>
        <source>E&apos; disponibile la nuova versione </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="411"/>
        <source>,se vuoi aggiornare clicca per aggiornare.
Se clicchi ok si chiude il programma e si aggiorna il software alla nuova versione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="431"/>
        <source>Errore...
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="466"/>
        <source>Devi riavviare per rendere effettive le modifiche....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="475"/>
        <location filename="../pref.cpp" line="511"/>
        <source>Errore di connessione al DB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="476"/>
        <source>Verificare che i dati siano corretti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="512"/>
        <source>Impossibile connettersi al db.Controllare le impostazioni.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="526"/>
        <source>Lylibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="528"/>
        <source>Creazione db strutturata con successo....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pref.cpp" line="436"/>
        <source>Stai usando la nuova versione</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>prest_lib</name>
    <message>
        <location filename="../ui/prest_lib.ui" line="14"/>
        <location filename="../ui_prest_lib.h" line="306"/>
        <source>Anagrafica rientri e prestiti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/prest_lib.ui" line="64"/>
        <location filename="../prest_lib.cpp" line="79"/>
        <location filename="../prest_lib.cpp" line="113"/>
        <location filename="../prest_lib.cpp" line="137"/>
        <location filename="../ui_prest_lib.h" line="308"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/prest_lib.ui" line="74"/>
        <location filename="../prest_lib.cpp" line="80"/>
        <location filename="../prest_lib.cpp" line="114"/>
        <location filename="../prest_lib.cpp" line="138"/>
        <location filename="../ui_prest_lib.h" line="309"/>
        <source>Cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/prest_lib.ui" line="84"/>
        <location filename="../prest_lib.cpp" line="81"/>
        <location filename="../prest_lib.cpp" line="115"/>
        <location filename="../prest_lib.cpp" line="139"/>
        <location filename="../ui_prest_lib.h" line="310"/>
        <source>Libro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/prest_lib.ui" line="94"/>
        <location filename="../prest_lib.cpp" line="82"/>
        <location filename="../prest_lib.cpp" line="116"/>
        <location filename="../prest_lib.cpp" line="140"/>
        <location filename="../ui_prest_lib.h" line="311"/>
        <source>Data prestito</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/prest_lib.ui" line="101"/>
        <location filename="../prest_lib.cpp" line="83"/>
        <location filename="../prest_lib.cpp" line="117"/>
        <location filename="../prest_lib.cpp" line="141"/>
        <location filename="../ui_prest_lib.h" line="312"/>
        <source>Data rientro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/prest_lib.ui" line="147"/>
        <location filename="../prest_lib.cpp" line="413"/>
        <location filename="../ui_prest_lib.h" line="319"/>
        <source>Visualizza lista completa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/prest_lib.ui" line="154"/>
        <location filename="../prest_lib.cpp" line="415"/>
        <location filename="../ui_prest_lib.h" line="320"/>
        <source>Visualizza lista libri rientrati</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/prest_lib.ui" line="161"/>
        <location filename="../ui_prest_lib.h" line="321"/>
        <source>Inserisci &quot;Rientrato&quot; e &quot;Non rientrato&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/prest_lib.ui" line="185"/>
        <location filename="../ui_prest_lib.h" line="323"/>
        <source>Cerca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/prest_lib.ui" line="196"/>
        <location filename="../ui_prest_lib.h" line="326"/>
        <source>Cerca per cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/prest_lib.ui" line="201"/>
        <location filename="../ui_prest_lib.h" line="327"/>
        <source>Cerca per libro prestato o non prestato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prest_lib.cpp" line="84"/>
        <location filename="../prest_lib.cpp" line="118"/>
        <location filename="../prest_lib.cpp" line="142"/>
        <source>Rientro libro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prest_lib.cpp" line="159"/>
        <location filename="../prest_lib.cpp" line="191"/>
        <location filename="../prest_lib.cpp" line="287"/>
        <source>LyLibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prest_lib.cpp" line="159"/>
        <source>Seleziona una riga da modificare...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prest_lib.cpp" line="163"/>
        <location filename="../prest_lib.cpp" line="212"/>
        <source>Non rientrato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prest_lib.cpp" line="163"/>
        <source>Rientrato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prest_lib.cpp" line="191"/>
        <source>Impossibile aggiornare i prestiti...
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prest_lib.cpp" line="269"/>
        <source>Lylibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prest_lib.cpp" line="270"/>
        <source>Avviso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prest_lib.cpp" line="271"/>
        <source>Inserisci il testo nella casella cerca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prest_lib.cpp" line="287"/>
        <source>Selezionare una riga da eliminare...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prest_lib.cpp" line="407"/>
        <source>Chiudi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prest_lib.cpp" line="410"/>
        <source>Elimina</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prest_lib.cpp" line="414"/>
        <source>Visualizza la lista dei prestiti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prest_lib.cpp" line="416"/>
        <source>Aggiorna</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presto</name>
    <message>
        <location filename="../ui/presto.ui" line="17"/>
        <location filename="../ui_presto.h" line="376"/>
        <source>Prestito libri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/presto.ui" line="67"/>
        <location filename="../ui_presto.h" line="379"/>
        <source>Nuovo </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/presto.ui" line="81"/>
        <location filename="../presto.cpp" line="590"/>
        <location filename="../ui_presto.h" line="383"/>
        <source>Salva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/presto.ui" line="95"/>
        <location filename="../ui_presto.h" line="387"/>
        <source>Modifica</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/presto.ui" line="109"/>
        <location filename="../presto.cpp" line="584"/>
        <location filename="../ui_presto.h" line="391"/>
        <source>Elimina</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/presto.ui" line="123"/>
        <location filename="../ui_presto.h" line="395"/>
        <source>Anteprima di stampa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/presto.ui" line="137"/>
        <location filename="../ui_presto.h" line="399"/>
        <source>Esci</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/presto.ui" line="160"/>
        <location filename="../ui_presto.h" line="403"/>
        <source>Cerca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/presto.ui" line="182"/>
        <location filename="../ui_presto.h" line="407"/>
        <source>Cerca per cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/presto.ui" line="187"/>
        <location filename="../ui_presto.h" line="408"/>
        <source>Cerca per libro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/presto.ui" line="198"/>
        <location filename="../ui_presto.h" line="410"/>
        <source>Informazioni</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/presto.ui" line="310"/>
        <location filename="../presto.cpp" line="363"/>
        <location filename="../ui_presto.h" line="412"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/presto.ui" line="324"/>
        <location filename="../ui_presto.h" line="413"/>
        <source>Cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/presto.ui" line="331"/>
        <location filename="../ui_presto.h" line="414"/>
        <source>Libro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/presto.ui" line="341"/>
        <location filename="../ui/presto.ui" line="375"/>
        <location filename="../ui_presto.h" line="415"/>
        <location filename="../ui_presto.h" line="419"/>
        <source>dd/MM/yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/presto.ui" line="348"/>
        <location filename="../presto.cpp" line="366"/>
        <location filename="../ui_presto.h" line="416"/>
        <source>Data prestito</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/presto.ui" line="355"/>
        <location filename="../presto.cpp" line="367"/>
        <location filename="../ui_presto.h" line="417"/>
        <source>Ora prestito</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/presto.ui" line="368"/>
        <location filename="../presto.cpp" line="369"/>
        <location filename="../ui_presto.h" line="418"/>
        <source>Ora rientro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/presto.ui" line="382"/>
        <location filename="../presto.cpp" line="368"/>
        <location filename="../ui_presto.h" line="420"/>
        <source>Data rientro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../presto.cpp" line="163"/>
        <location filename="../presto.cpp" line="238"/>
        <location filename="../presto.cpp" line="314"/>
        <source>LyLibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../presto.cpp" line="163"/>
        <source>Inserisci correttamente i dati</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../presto.cpp" line="225"/>
        <source>Impossibile inserire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../presto.cpp" line="226"/>
        <source>Impossibile inserire </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../presto.cpp" line="238"/>
        <source>Seleziona una riga da modificare....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../presto.cpp" line="296"/>
        <source>Voce non aggiornabile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../presto.cpp" line="297"/>
        <source>Impossibile aggiornare</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../presto.cpp" line="314"/>
        <source>Selezionare una riga da eliminare...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../presto.cpp" line="364"/>
        <source>Cliente.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../presto.cpp" line="365"/>
        <source>Libro.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../presto.cpp" line="394"/>
        <source>ID: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../presto.cpp" line="395"/>
        <source>Cliente: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../presto.cpp" line="396"/>
        <source>Libro: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../presto.cpp" line="397"/>
        <source>Data prestito: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../presto.cpp" line="398"/>
        <source>Ora prestito: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../presto.cpp" line="399"/>
        <source>Data rientro: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../presto.cpp" line="400"/>
        <source>Ora rientro: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../presto.cpp" line="493"/>
        <source>Anteprima di stampa.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../presto.cpp" line="581"/>
        <source>Chiudi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../presto.cpp" line="587"/>
        <source>Nuovo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../presto.cpp" line="593"/>
        <source>Aggiorna</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../presto.cpp" line="596"/>
        <source>Stampa</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>scarico_mag</name>
    <message>
        <location filename="../ui/scarico_mag.ui" line="14"/>
        <location filename="../ui_scarico_mag.h" line="173"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/scarico_mag.ui" line="20"/>
        <location filename="../ui_scarico_mag.h" line="174"/>
        <source>Scarico magazzino</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/scarico_mag.ui" line="26"/>
        <location filename="../ui_scarico_mag.h" line="175"/>
        <source>Totale vendita prodotti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/scarico_mag.ui" line="50"/>
        <location filename="../ui_scarico_mag.h" line="176"/>
        <source>Informazioni dettagliate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/scarico_mag.ui" line="71"/>
        <location filename="../ui_scarico_mag.h" line="177"/>
        <source>Quantità venduta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="33"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="34"/>
        <source>Codice a barre.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="35"/>
        <source>Titolo.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="36"/>
        <source>Descrizione.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="37"/>
        <source>Autore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="38"/>
        <source>Lingua</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="39"/>
        <source>Categoria</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="40"/>
        <source>Collocazione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="42"/>
        <source>Prezzo unitario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="43"/>
        <source>Prezzo senza iva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="44"/>
        <source>Prezzo con iva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="45"/>
        <source>Totale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="46"/>
        <source>Info editore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="47"/>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="80"/>
        <source>Cod. Art.: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="81"/>
        <source>Codice a barre: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="82"/>
        <source>Titolo: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="83"/>
        <source>Descrizione: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="84"/>
        <source>Autore: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="85"/>
        <source>Lingua: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="86"/>
        <source>Categoria libro: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="87"/>
        <source>Info editore: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="88"/>
        <source>Collocazione: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="89"/>
        <source>Prezzo unitario: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="90"/>
        <source>Prezzo senza iva: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="91"/>
        <source>Prezzo con iva: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="92"/>
        <source>Totale: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="112"/>
        <location filename="../scarico_mag.cpp" line="127"/>
        <location filename="../scarico_mag.cpp" line="142"/>
        <location filename="../scarico_mag.cpp" line="235"/>
        <location filename="../scarico_mag.cpp" line="259"/>
        <location filename="../scarico_mag.cpp" line="296"/>
        <source>LyLibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="142"/>
        <source>Impossibile instanziare il prezzo totale degli articoli venduti...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="149"/>
        <source>Esporta CSV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="150"/>
        <source>CSV(*.csv);;Tutti i file(*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="235"/>
        <source>Selezionare una riga da esportare in csv...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="242"/>
        <source>Esporta PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="243"/>
        <source>Pdf Files(*.pdf);;Tutti i file(*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="259"/>
        <source>Selezionare una riga da esportare in pdf...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="278"/>
        <location filename="../scarico_mag.cpp" line="313"/>
        <source>Lylibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="279"/>
        <source>Vuoi eliminare veramente 
 il record selezionato?....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="314"/>
        <source>Impossibile eliminare 
 il record selezionato?....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="296"/>
        <source>Selezionare una riga da eliminare...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="41"/>
        <source>Quantità</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="104"/>
        <source>Quantità: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="112"/>
        <source>Impossibile cercare...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="127"/>
        <source>Impossibile instanziare la quantità di articoli venduti...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scarico_mag.cpp" line="327"/>
        <source>Anteprima di stampa.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>sound</name>
    <message>
        <location filename="../sound.cpp" line="26"/>
        <source>Formato raw non supportato. Impossibile avviare audio...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>update</name>
    <message>
        <location filename="../../update/update.ui" line="14"/>
        <location filename="../../update/ui_update.h" line="144"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/update.ui" line="36"/>
        <location filename="../../update/ui_update.h" line="148"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Annulla download&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/update.ui" line="84"/>
        <location filename="../../update/ui_update.h" line="155"/>
        <source>Installazione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/update.ui" line="91"/>
        <location filename="../../update/update.ui" line="134"/>
        <location filename="../../update/ui_update.h" line="156"/>
        <location filename="../../update/ui_update.h" line="163"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Download aggiornamento&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/update.ui" line="120"/>
        <location filename="../../update/ui_update.h" line="159"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Installa aggiornamento&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/update.ui" line="123"/>
        <location filename="../../update/ui_update.h" line="161"/>
        <source>Installa aggiornamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/update.ui" line="137"/>
        <location filename="../../update/ui_update.h" line="165"/>
        <source>Download aggiornamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/update.cpp" line="16"/>
        <source>Gestore aggiornamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/update.cpp" line="43"/>
        <source>Scaricamento in corso di:  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/update.cpp" line="110"/>
        <source>Velocità di scaricamento: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/update.cpp" line="110"/>
        <source>  Dimensione: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/update.cpp" line="110"/>
        <source> Tempo stimato: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/update.cpp" line="131"/>
        <source>Download fallito: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/update.cpp" line="140"/>
        <source>Scaricamento completato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/update.cpp" line="155"/>
        <source>Scaricamento annullato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/update.cpp" line="159"/>
        <source>Errore scaricamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../update/update.cpp" line="220"/>
        <source>Download fallito </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>update_db</name>
    <message>
        <location filename="../../initdb/update_db.ui" line="14"/>
        <location filename="../../initdb/ui_update_db.h" line="136"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/update_db.ui" line="20"/>
        <location filename="../../initdb/ui_update_db.h" line="137"/>
        <location filename="../../initdb/update_db.cpp" line="10"/>
        <source>Aggiornamento database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/update_db.ui" line="44"/>
        <location filename="../../initdb/ui_update_db.h" line="138"/>
        <source>Processo in corso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/update_db.ui" line="94"/>
        <location filename="../../initdb/ui_update_db.h" line="140"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;Aggiornamento del Database LyLibrary &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/update_db.ui" line="121"/>
        <location filename="../../initdb/ui_update_db.h" line="141"/>
        <source>Aggiorna</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/update_db.ui" line="138"/>
        <location filename="../../initdb/ui_update_db.h" line="142"/>
        <source>Chiudi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/update_db.cpp" line="75"/>
        <source>Aggiornamento database locale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../initdb/update_db.cpp" line="77"/>
        <source>Aggiornamento database in corso...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>user</name>
    <message>
        <location filename="../ui/user.ui" line="23"/>
        <location filename="../ui_user.h" line="416"/>
        <source>Clienti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/user.ui" line="190"/>
        <location filename="../ui_user.h" line="427"/>
        <source>Telefono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/user.ui" line="197"/>
        <location filename="../ui_user.h" line="428"/>
        <source>E-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/user.ui" line="207"/>
        <location filename="../ui_user.h" line="429"/>
        <source>Indirizzo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/user.ui" line="214"/>
        <location filename="../ui_user.h" line="430"/>
        <source>Cognome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/user.ui" line="235"/>
        <location filename="../ui_user.h" line="431"/>
        <location filename="../user.cpp" line="278"/>
        <source>Fax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/user.ui" line="245"/>
        <location filename="../ui_user.h" line="432"/>
        <source>P.I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/user.ui" line="298"/>
        <location filename="../ui_user.h" line="433"/>
        <location filename="../user.cpp" line="271"/>
        <source>Nome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/user.ui" line="305"/>
        <location filename="../ui_user.h" line="434"/>
        <location filename="../user.cpp" line="270"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/user.ui" line="312"/>
        <location filename="../ui_user.h" line="435"/>
        <location filename="../user.cpp" line="276"/>
        <source>Codice fiscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/user.ui" line="119"/>
        <location filename="../ui_user.h" line="419"/>
        <source>Totale clienti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/user.ui" line="130"/>
        <location filename="../ui_user.h" line="422"/>
        <source>Cerca per nome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/user.ui" line="135"/>
        <location filename="../ui_user.h" line="423"/>
        <source>Cerca per cognome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/user.ui" line="143"/>
        <location filename="../ui_user.h" line="425"/>
        <source>Cerca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/user.ui" line="153"/>
        <location filename="../ui_user.h" line="426"/>
        <source>Informazioni</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/user.ui" line="340"/>
        <location filename="../ui_user.h" line="437"/>
        <source>Anteprima di stampa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/user.ui" line="396"/>
        <location filename="../ui_user.h" line="453"/>
        <location filename="../user.cpp" line="632"/>
        <source>Salva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/user.ui" line="424"/>
        <location filename="../ui_user.h" line="461"/>
        <location filename="../user.cpp" line="629"/>
        <source>Nuovo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/user.ui" line="354"/>
        <location filename="../ui_user.h" line="441"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Chiudi&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/user.ui" line="382"/>
        <location filename="../ui_user.h" line="449"/>
        <location filename="../user.cpp" line="626"/>
        <source>Elimina</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/user.ui" line="368"/>
        <location filename="../ui_user.h" line="445"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Esporta in pdf&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/user.ui" line="410"/>
        <location filename="../ui_user.h" line="457"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Esporta in csv&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="99"/>
        <location filename="../user.cpp" line="213"/>
        <location filename="../user.cpp" line="387"/>
        <source>LyLibrary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="99"/>
        <source>Inserisci correttamente i dati</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="213"/>
        <source>Selezionare una riga da eliminare...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="252"/>
        <source>Errore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="253"/>
        <source>Impossibile eliminare record poichè non hai selezionato nulla</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="272"/>
        <source>Cognome.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="273"/>
        <source>Indirizzo.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="274"/>
        <source>Telefono.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="275"/>
        <source>E-mail.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="277"/>
        <source>Partita Iva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="300"/>
        <source>ID: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="301"/>
        <source>Nome: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="302"/>
        <source>Cognome: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="303"/>
        <source>Indirizzo: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="304"/>
        <source>Telefono: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="305"/>
        <source>E-mail: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="306"/>
        <source>Codice fiscale: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="307"/>
        <source>Partita iva: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="308"/>
        <source>Fax: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="388"/>
        <source>Avviso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="389"/>
        <source>Inserisci il testo nella casella cerca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="406"/>
        <source>Anteprima di stampa.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="423"/>
        <source>Esporta PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="424"/>
        <source>Pdf Files(*.pdf);;Tutti i file(*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="442"/>
        <source>Esporta CSV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="443"/>
        <source>CSV(*.csv);;Tutti i file(*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="623"/>
        <source>Chiudi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="635"/>
        <source>Aggiorna</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="638"/>
        <source>Stampa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="641"/>
        <source>Esporta pdf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../user.cpp" line="644"/>
        <source>Esporta csv</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>verify_codicefiscale</name>
    <message>
        <location filename="../ui/verify_codicefiscale.ui" line="20"/>
        <location filename="../ui_verify_codicefiscale.h" line="124"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/verify_codicefiscale.ui" line="26"/>
        <location filename="../ui_verify_codicefiscale.h" line="125"/>
        <location filename="../verify_codicefiscale.cpp" line="49"/>
        <source>Verifica il tuo codice fiscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/verify_codicefiscale.ui" line="55"/>
        <location filename="../ui_verify_codicefiscale.h" line="127"/>
        <source>Inserisci il codice fiscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/verify_codicefiscale.ui" line="107"/>
        <location filename="../ui_verify_codicefiscale.h" line="130"/>
        <source>Verifica</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/verify_codicefiscale.ui" line="118"/>
        <location filename="../ui_verify_codicefiscale.h" line="131"/>
        <source>Esci</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../verify_codicefiscale.cpp" line="66"/>
        <source>Errore: Non hai inserito nessun carattere o numero...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../verify_codicefiscale.cpp" line="68"/>
        <source>La lunghezza del codice fiscale non è
corretta: il codice fiscale deve essere lungo
esattamente 16 caratteri...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../verify_codicefiscale.cpp" line="72"/>
        <source>Il codice fiscale inserito non è corretto.
Il codice di controllo non corrisponde.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../verify_codicefiscale.cpp" line="78"/>
        <source>Il codice fiscale inserito è corretto.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../verify_codicefiscale.cpp" line="75"/>
        <source>Il codice fiscale contiene dei caratteri non validi:
i soli caratteri validi sono le lettere e le cifre.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>verify_piva</name>
    <message>
        <location filename="../ui/verify_piva.ui" line="20"/>
        <location filename="../ui_verify_piva.h" line="123"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/verify_piva.ui" line="26"/>
        <location filename="../ui_verify_piva.h" line="124"/>
        <source>Esci</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/verify_piva.ui" line="37"/>
        <location filename="../ui_verify_piva.h" line="125"/>
        <source>Verifica</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/verify_piva.ui" line="61"/>
        <location filename="../ui_verify_piva.h" line="126"/>
        <source>Verifica la partita iva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/verify_piva.ui" line="90"/>
        <location filename="../ui_verify_piva.h" line="128"/>
        <source>Inserisci la partita iva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../verify_piva.cpp" line="49"/>
        <source>Controlla la tua partita iva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../verify_piva.cpp" line="68"/>
        <source>Errore: Non hai inserito nessun numero.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../verify_piva.cpp" line="70"/>
        <source>La lunghezza della partita IVA non è
corretta: la partita iva deve essere lunga
esattamente 11 caratteri numerici</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../verify_piva.cpp" line="74"/>
        <source>La partita IVA non è valida:
il codice di controllo non corrisponde</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../verify_piva.cpp" line="77"/>
        <source>La partita iva è corretta.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
